const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { Plus, Clock, Sparkles, Layers } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

import { ScrollArea } from '@/components/ui/scroll-area';
import moment from 'moment';

export default function Sidebar({ activeId, onSelect, onNew }) {
  const { data: generations = [] } = useQuery({
    queryKey: ['generations'],
    queryFn: () => db.entities.Generation.list('-created_date', 50),
  });

  return (
    <div className="w-64 h-screen bg-sidebar border-r border-sidebar-border flex flex-col shrink-0">
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-7 h-7 rounded-md bg-primary flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-mono font-bold text-foreground tracking-tight">AUTOWEB</span>
        </div>
        <button
          onClick={onNew}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-md border border-border text-sm font-mono text-muted-foreground hover:text-foreground hover:border-primary/50 transition-colors"
        >
          <Plus className="w-4 h-4" />
          NEW GENERATION
        </button>
      </div>

      <div className="px-4 pt-4 pb-2">
        <div className="flex items-center gap-1.5 text-xs font-mono text-muted-foreground tracking-wider">
          <Clock className="w-3 h-3" />
          HISTORY
        </div>
      </div>

      <ScrollArea className="flex-1 px-2">
        <div className="space-y-0.5 pb-4">
          {generations.map((gen) => (
            <button
              key={gen.id}
              onClick={() => onSelect(gen)}
              className={`w-full text-left px-3 py-2.5 rounded-md transition-colors ${
                activeId === gen.id
                  ? 'bg-sidebar-accent text-foreground'
                  : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
              }`}
            >
              <div className="text-sm truncate font-medium">{gen.title}</div>
              <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1.5">
                {moment(gen.created_date).format('M/D/YYYY')}
                <span>·</span>
                <Layers className="w-3 h-3 inline" />
                {gen.section_count || gen.sections?.length || 0} sections
              </div>
            </button>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}