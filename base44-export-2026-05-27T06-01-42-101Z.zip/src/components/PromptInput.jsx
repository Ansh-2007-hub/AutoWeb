import { useState } from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';

const SUGGESTIONS = [
  "A minimal portfolio website for a Tokyo-based product designer",
  "A landing page for an AI-powered note-taking app called Nebula",
  "A modern bakery website with menu, location, and online ordering CTA",
  "A SaaS pricing page for a developer tool with three tiers",
];

export default function PromptInput({ onGenerate, isGenerating }) {
  const [prompt, setPrompt] = useState('');

  const handleSubmit = () => {
    if (!prompt.trim() || isGenerating) return;
    onGenerate(prompt.trim());
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-8 max-w-3xl mx-auto w-full">
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-2 text-xs font-mono text-muted-foreground border border-border rounded-full px-3 py-1 mb-8">
          <Sparkles className="w-3 h-3 text-primary" />
          GEMINI · TAILWIND · LIVE PREVIEW
        </div>
        <h1 className="text-5xl font-bold tracking-tight leading-tight">
          Describe a website.
          <br />
          <span className="text-primary">Ship it.</span>
        </h1>
        <p className="text-muted-foreground mt-4 text-base">
          Type intent. Get a fully structured website with editable sections and exportable code.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 w-full mb-8">
        {SUGGESTIONS.map((s, i) => (
          <button
            key={i}
            onClick={() => setPrompt(s)}
            className="text-left px-4 py-3 rounded-lg border border-border text-sm text-muted-foreground hover:text-foreground hover:border-primary/40 transition-colors flex items-start gap-2"
          >
            <ArrowRight className="w-3.5 h-3.5 mt-0.5 shrink-0 text-muted-foreground" />
            {s}
          </button>
        ))}
      </div>

      <div className="w-full border border-border rounded-xl bg-card p-1.5 flex items-end gap-2">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSubmit(); }}}
          placeholder="Describe the website you want — e.g. a modern portfolio for a photographer"
          rows={2}
          className="flex-1 bg-transparent resize-none text-sm text-foreground placeholder:text-muted-foreground p-3 focus:outline-none"
        />
        <button
          onClick={handleSubmit}
          disabled={!prompt.trim() || isGenerating}
          className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-mono font-semibold hover:bg-primary/90 disabled:opacity-40 transition-all shrink-0 mb-1 mr-1"
        >
          {isGenerating ? (
            <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
          ) : (
            <Sparkles className="w-4 h-4" />
          )}
          GENERATE
        </button>
      </div>
    </div>
  );
}