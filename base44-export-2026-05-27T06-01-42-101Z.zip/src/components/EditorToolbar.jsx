import { Monitor, Tablet, Smartphone, Code, Layers, Download, ExternalLink } from 'lucide-react';
import { Sparkles } from 'lucide-react';

export default function EditorToolbar({ title, view, onViewChange, viewport, onViewportChange, onExportHTML, onLaunch }) {
  return (
    <div className="h-12 border-b border-border bg-card flex items-center px-4 gap-3 shrink-0">
      <Sparkles className="w-4 h-4 text-primary" />
      <span className="text-sm font-medium truncate max-w-xs">{title}</span>

      <div className="flex-1" />

      <div className="flex items-center gap-1 bg-secondary rounded-md p-0.5">
        {[
          { id: 'desktop', icon: Monitor },
          { id: 'tablet', icon: Tablet },
          { id: 'mobile', icon: Smartphone },
        ].map(({ id, icon: Icon }) => (
          <button
            key={id}
            onClick={() => onViewportChange?.(id)}
            className={`p-1.5 rounded transition-colors ${
              viewport === id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
            }`}
            title={id.charAt(0).toUpperCase() + id.slice(1)}
          >
            <Icon className="w-4 h-4" />
          </button>
        ))}
      </div>

      <div className="h-5 w-px bg-border" />

      <div className="flex items-center gap-0.5 bg-secondary rounded-md p-0.5">
        <button
          onClick={() => onViewChange('sections')}
          className={`px-3 py-1.5 rounded text-xs font-mono font-semibold transition-colors ${view === 'sections' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
        >
          <span className="flex items-center gap-1"><Layers className="w-3 h-3" /> SECTIONS</span>
        </button>
        <button
          onClick={() => onViewChange('code')}
          className={`px-3 py-1.5 rounded text-xs font-mono font-semibold transition-colors ${view === 'code' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
        >
          <span className="flex items-center gap-1"><Code className="w-3 h-3" /> CODE</span>
        </button>
      </div>

      <div className="h-5 w-px bg-border" />

      <button onClick={onExportHTML} className="p-1.5 rounded text-muted-foreground hover:text-foreground transition-colors" title="Download HTML">
        <Download className="w-4 h-4" />
      </button>
      <button onClick={onLaunch} className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-mono font-semibold hover:bg-primary/90 transition-colors">
        <ExternalLink className="w-3.5 h-3.5" />
        LAUNCH
      </button>
    </div>
  );
}