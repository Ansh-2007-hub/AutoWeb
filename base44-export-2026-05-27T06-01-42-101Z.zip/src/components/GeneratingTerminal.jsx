import { useEffect, useState } from 'react';
import { Sparkles } from 'lucide-react';

const STEPS = [
  '$ parsing intent...',
  '$ designing information architecture...',
  '$ composing hero + value proposition...',
  '$ wiring features and social proof...',
  '$ tailwind utilities — pass 1/2...',
  '$ tailwind utilities — pass 2/2...',
  '$ finalizing sections...',
];

export default function GeneratingTerminal({ prompt }) {
  const [completedSteps, setCompletedSteps] = useState(0);
  const [currentLabel, setCurrentLabel] = useState('thinking');

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      if (i < STEPS.length) {
        setCompletedSteps(i + 1);
        setCurrentLabel('thinking');
        i++;
      }
    }, 900);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-background">
      <div className="w-full max-w-2xl px-8">
        <div className="flex items-center gap-2 mb-8">
          <Sparkles className="w-4 h-4 text-primary" />
          <span className="font-mono text-xs text-muted-foreground tracking-widest uppercase">INTENT → INTERFACE</span>
        </div>

        <div className="font-mono text-sm space-y-2">
          <div className="text-primary font-semibold mb-4 tracking-widest text-xs">// GENERATING</div>
          {STEPS.map((step, i) => {
            const isActive = i === completedSteps - 1;
            const isDone = i < completedSteps - 1;
            const isPending = i >= completedSteps;
            return (
              <div
                key={i}
                className={`flex items-center gap-3 transition-all duration-300 ${
                  isPending ? 'opacity-20' : isDone ? 'opacity-50' : 'opacity-100'
                }`}
              >
                <span className={`text-xs ${isDone ? 'text-muted-foreground' : isActive ? 'text-primary' : 'text-muted-foreground'}`}>
                  [{String(i + 1).padStart(2, '0')}]
                </span>
                <span className={`${isActive ? 'text-foreground' : isDone ? 'text-muted-foreground' : 'text-muted-foreground'}`}>
                  {step}
                </span>
                {isActive && (
                  <span className="inline-block w-1.5 h-4 bg-primary animate-pulse ml-1" />
                )}
              </div>
            );
          })}
          {completedSteps >= STEPS.length && (
            <div className="flex items-center gap-3 text-muted-foreground opacity-60">
              <span className="text-xs text-muted-foreground">[{String(STEPS.length + 1).padStart(2, '0')}]</span>
              <span>{currentLabel}</span>
              <span className="inline-block w-1.5 h-4 bg-muted-foreground animate-pulse ml-1" />
            </div>
          )}
        </div>

        {prompt && (
          <div className="mt-8 px-4 py-3 rounded-lg bg-secondary/40 border border-border">
            <span className="text-xs text-muted-foreground font-mono">» </span>
            <span className="text-xs text-muted-foreground font-mono italic">{prompt}</span>
          </div>
        )}
      </div>
    </div>
  );
}