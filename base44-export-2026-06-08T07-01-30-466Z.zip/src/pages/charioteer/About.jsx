import { Link } from 'react-router-dom';
import CharioteerLayout from './Layout';

export default function CharioteerAbout() {
  return (
    <CharioteerLayout>
      {/* Hero */}
      <section style={{ padding: '100px 24px 80px', background: 'linear-gradient(135deg,#030712,#0a0f1e)', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', width: '500px', height: '500px', background: 'rgba(245,158,11,0.06)', borderRadius: '50%', top: '-150px', right: '-100px', filter: 'blur(80px)', pointerEvents: 'none' }} />
        <div style={{ maxWidth: '1200px', margin: '0 auto', position: 'relative', zIndex: 1 }}>
          <div className="badge-label"><span>ABOUT US</span></div>
          <h1 style={{ fontSize: 'clamp(36px,4.5vw,60px)', fontWeight: 800, letterSpacing: '-2px', marginBottom: '20px', maxWidth: '700px' }}>
            Fortunate to Have You at <span className="grad-text">Charioteer</span>
          </h1>
          <p style={{ fontSize: '17px', lineHeight: 1.8, maxWidth: '680px', marginBottom: '36px' }}>
            At Charioteer Blockchain & AI Solutions Pvt. Ltd., recognized as one of the <strong style={{ color: 'white' }}>best Blockchain Training Institutes in India</strong>, we deliver comprehensive online and offline training programs in Blockchain, Metaverse, Digital Marketing, and Artificial Intelligence.
          </p>
          <p style={{ fontSize: '16px', lineHeight: 1.8, maxWidth: '680px' }}>
            We also provide expert academic consultation services for M.Tech, MBA, and LLB students — offering personalized guidance in research, thesis writing, and project development. Our industry-aligned internships focus on practical, job-ready skills in .NET, PHP, Python, Java, MATLAB, and more.
          </p>
        </div>
      </section>

      {/* Mission / Vision / Values */}
      <section className="section-pad section-mid">
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '24px', marginBottom: '64px' }}>
            {[
              ['🎯', 'Our Mission', 'rgba(245,158,11,0.08)', 'rgba(245,158,11,0.2)', 'Empower people and businesses with trust, transparency, and practical skills in Blockchain, Web3, AI, and more — combining career success with ethical innovation.'],
              ['🔭', 'Our Vision', 'rgba(139,92,246,0.08)', 'rgba(139,92,246,0.2)', 'By 2030, we aim to teach one billion people fair and safe practices in Blockchain and Web3, empowering them with knowledge and confidence for the digital future.'],
              ['⚡', 'Our Values (RAPID)', 'rgba(34,197,94,0.08)', 'rgba(34,197,94,0.2)', 'Respect · Accountability · Perseverance · Integrity · Diligence — five core values guiding how we work, stay honest, and deliver our best with purpose and passion.'],
            ].map(([icon, title, bg, border, desc]) => (
              <div key={title} style={{ background: bg, border: `1px solid ${border}`, borderRadius: '20px', padding: '32px' }}>
                <div style={{ fontSize: '32px', marginBottom: '14px' }}>{icon}</div>
                <h3 style={{ fontSize: '18px', fontWeight: 700, marginBottom: '12px' }}>{title}</h3>
                <p style={{ fontSize: '14px', lineHeight: 1.7 }}>{desc}</p>
              </div>
            ))}
          </div>

          {/* RAPID values detail */}
          <div style={{ textAlign: 'center', marginBottom: '40px' }}>
            <h2 style={{ fontSize: 'clamp(28px,3.5vw,44px)', fontWeight: 800, letterSpacing: '-1.5px' }}>Built on <span className="grad-text">RAPID</span> Values</h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: '14px' }}>
            {[['R', 'Respect', 'Valuing every individual and perspective.'],
              ['A', 'Accountability', 'Owning our commitments and outcomes.'],
              ['P', 'Perseverance', 'Staying committed through every challenge.'],
              ['I', 'Integrity', 'Ethical and transparent in all we do.'],
              ['D', 'Diligence', 'Delivering our best with purpose.']].map(([letter, name, desc]) => (
              <div key={letter} style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(245,158,11,0.15)', borderRadius: '16px', padding: '24px 16px', textAlign: 'center' }}>
                <div style={{ width: '44px', height: '44px', background: 'linear-gradient(135deg,#f59e0b,#f97316)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#030712', fontWeight: 900, fontSize: '20px', margin: '0 auto 14px' }}>{letter}</div>
                <div style={{ color: 'white', fontWeight: 700, fontSize: '14px', marginBottom: '8px' }}>{name}</div>
                <p style={{ fontSize: '12px', lineHeight: 1.6 }}>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Clients */}
      <section className="section-pad section-dark">
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '48px' }}>
            <div className="badge-label" style={{ justifyContent: 'center' }}><span>OUR CLIENTS</span></div>
            <h2 style={{ fontSize: 'clamp(28px,3.5vw,44px)', fontWeight: 800, letterSpacing: '-1px' }}>Who We <span className="grad-text">Serve</span></h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '20px' }}>
            {[['💼', 'MBA, LLB, MCA, M.Tech Candidates', 'Seeking career guidance and academic support for their professional journey.'],
              ['👩💻', 'Working Professionals', 'Aiming for skill enhancement and growth in emerging technologies.'],
              ['💡', 'Investors & Consultants', 'Exploring reliable research and consulting support in Blockchain and AI.']].map(([icon, title, desc]) => (
              <div key={title} className="card">
                <div style={{ fontSize: '30px', marginBottom: '14px' }}>{icon}</div>
                <h3 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '10px' }}>{title}</h3>
                <p style={{ fontSize: '13px', lineHeight: 1.7 }}>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Academic Partners */}
      <section className="section-pad section-mid">
        <div style={{ maxWidth: '1200px', margin: '0 auto', textAlign: 'center' }}>
          <div className="badge-label" style={{ justifyContent: 'center' }}><span>ACADEMIC PARTNERS</span></div>
          <h2 style={{ fontSize: 'clamp(28px,3.5vw,44px)', fontWeight: 800, letterSpacing: '-1px', marginBottom: '40px' }}>Our Trusted <span className="grad-text">Partners</span></h2>
          <div style={{ display: 'flex', gap: '24px', justifyContent: 'center', flexWrap: 'wrap' }}>
            {[['CoreDAO', 'Blockchain infrastructure partner'], ['JIET', 'Academic institution partner'], ['Universities', 'Research collaborations'], ['Publishing Houses', 'Academic content partner']].map(([name, desc]) => (
              <div key={name} style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '16px', padding: '24px 32px', minWidth: '180px' }}>
                <div style={{ color: 'white', fontWeight: 700, fontSize: '15px', marginBottom: '6px' }}>{name}</div>
                <div style={{ color: 'rgba(255,255,255,0.35)', fontSize: '12px' }}>{desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </CharioteerLayout>
  );
}