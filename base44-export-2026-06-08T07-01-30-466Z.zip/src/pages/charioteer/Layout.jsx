import { Link, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { Menu, X } from 'lucide-react';

const navLinks = [
  { label: 'Home', path: '/charioteer' },
  { label: 'About', path: '/charioteer/about' },
  { label: 'Services', path: '/charioteer/services' },
  { label: 'Training', path: '/charioteer/training' },
  { label: 'Research', path: '/charioteer/research' },
  { label: 'Contact', path: '/charioteer/contact' },
];

export default function CharioteerLayout({ children }) {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div style={{ fontFamily: "'Space Grotesk', sans-serif", background: '#030712', minHeight: '100vh' }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700;800&display=swap');
        html { scroll-behavior: smooth; }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        .nav-link { color: rgba(255,255,255,0.65); text-decoration: none; font-size: 14px; font-weight: 500; padding: 6px 4px; border-bottom: 2px solid transparent; transition: all 0.2s; }
        .nav-link:hover { color: #f59e0b; }
        .nav-link.active { color: #f59e0b; border-bottom-color: #f59e0b; }
        .btn-primary { background: linear-gradient(135deg,#f59e0b,#f97316); color: #030712; padding: 11px 26px; border-radius: 9px; font-weight: 700; font-size: 14px; text-decoration: none; transition: opacity 0.2s; display: inline-block; }
        .btn-primary:hover { opacity: 0.85; }
        .btn-ghost { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12); color: white; padding: 11px 26px; border-radius: 9px; font-weight: 600; font-size: 14px; text-decoration: none; transition: all 0.2s; display: inline-block; }
        .btn-ghost:hover { background: rgba(255,255,255,0.1); }
        .card { background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.07); border-radius: 20px; padding: 28px; transition: all 0.3s; }
        .card:hover { border-color: rgba(245,158,11,0.3); transform: translateY(-4px); }
        .tag-gold { background: rgba(245,158,11,0.1); color: #f59e0b; padding: 4px 14px; border-radius: 100px; font-size: 12px; font-weight: 600; display: inline-block; }
        .badge-label { display: inline-flex; align-items: center; gap: 8px; background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.2); border-radius: 100px; padding: 6px 16px; margin-bottom: 20px; }
        .badge-label span { color: #f59e0b; font-size: 12px; font-weight: 600; letter-spacing: 1px; }
        .grad-text { background: linear-gradient(135deg,#f59e0b,#f97316); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
        .section-pad { padding: 88px 24px; }
        .section-dark { background: #030712; }
        .section-mid { background: #050a14; }
        h1,h2,h3,h4 { color: white; }
        p { color: rgba(255,255,255,0.5); }
        a { font-family: inherit; }
      `}</style>

      {/* Navbar */}
      <nav style={{ position: 'sticky', top: 0, zIndex: 1000, background: 'rgba(3,7,18,0.93)', backdropFilter: 'blur(16px)', borderBottom: '1px solid rgba(245,158,11,0.12)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px', height: '66px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Link to="/charioteer" style={{ display: 'flex', alignItems: 'center', gap: '11px', textDecoration: 'none' }}>
            <div style={{ width: '36px', height: '36px', background: 'linear-gradient(135deg,#f59e0b,#f97316)', borderRadius: '9px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px' }}>⚡</div>
            <div>
              <div style={{ color: 'white', fontWeight: 800, fontSize: '16px', letterSpacing: '-0.3px' }}>Charioteer</div>
              <div style={{ color: 'rgba(245,158,11,0.7)', fontSize: '9px', fontWeight: 600, letterSpacing: '1.5px' }}>BLOCKCHAIN & AI SOLUTIONS</div>
            </div>
          </Link>

          {/* Desktop nav */}
          <div style={{ display: 'flex', gap: '28px', alignItems: 'center' }} className="desktop-nav">
            {navLinks.map(l => (
              <Link key={l.path} to={l.path} className={`nav-link ${location.pathname === l.path ? 'active' : ''}`}>{l.label}</Link>
            ))}
          </div>
          <Link to="/charioteer/contact" className="btn-primary" style={{ padding: '9px 22px', fontSize: '13px' }}>Get Started →</Link>

          <button onClick={() => setMobileOpen(!mobileOpen)} style={{ display: 'none', background: 'none', border: 'none', color: 'white', cursor: 'pointer' }} className="mobile-menu-btn">
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {/* Mobile nav */}
        {mobileOpen && (
          <div style={{ background: '#0a0f1e', borderTop: '1px solid rgba(255,255,255,0.07)', padding: '16px 24px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {navLinks.map(l => (
              <Link key={l.path} to={l.path} onClick={() => setMobileOpen(false)} style={{ color: location.pathname === l.path ? '#f59e0b' : 'rgba(255,255,255,0.65)', textDecoration: 'none', fontWeight: 600, fontSize: '15px', padding: '8px 0' }}>{l.label}</Link>
            ))}
          </div>
        )}
      </nav>

      <main>{children}</main>

      {/* Footer */}
      <footer style={{ background: '#020509', borderTop: '1px solid rgba(245,158,11,0.1)', padding: '60px 24px 32px' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: '40px', marginBottom: '48px' }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '16px' }}>
                <div style={{ width: '34px', height: '34px', background: 'linear-gradient(135deg,#f59e0b,#f97316)', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '17px' }}>⚡</div>
                <div>
                  <div style={{ color: 'white', fontWeight: 800, fontSize: '15px' }}>Charioteer</div>
                  <div style={{ color: 'rgba(245,158,11,0.7)', fontSize: '9px', fontWeight: 600, letterSpacing: '1.5px' }}>BLOCKCHAIN & AI SOLUTIONS</div>
                </div>
              </div>
              <p style={{ fontSize: '13px', lineHeight: 1.7, maxWidth: '260px' }}>India's leading Blockchain & AI training institute — empowering professionals, researchers, and students.</p>
              <a href="https://charioteer.io" target="_blank" rel="noreferrer" style={{ color: '#f59e0b', fontSize: '13px', fontWeight: 600, textDecoration: 'none', display: 'inline-block', marginTop: '12px' }}>🌐 charioteer.io →</a>
            </div>
            <div>
              <div style={{ color: 'white', fontWeight: 700, fontSize: '13px', letterSpacing: '1px', marginBottom: '16px' }}>SERVICES</div>
              {['Online Training', 'Offline Training', 'Industrial Internships', 'Research Helpdesk'].map(s => (
                <div key={s} style={{ marginBottom: '10px' }}><Link to="/charioteer/services" style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px', textDecoration: 'none' }}>{s}</Link></div>
              ))}
            </div>
            <div>
              <div style={{ color: 'white', fontWeight: 700, fontSize: '13px', letterSpacing: '1px', marginBottom: '16px' }}>PROGRAMS</div>
              {['Blockchain & Web3', 'Artificial Intelligence', 'Metaverse', 'Digital Marketing', 'Python / Java / .NET'].map(s => (
                <div key={s} style={{ marginBottom: '10px' }}><Link to="/charioteer/training" style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px', textDecoration: 'none' }}>{s}</Link></div>
              ))}
            </div>
            <div>
              <div style={{ color: 'white', fontWeight: 700, fontSize: '13px', letterSpacing: '1px', marginBottom: '16px' }}>QUICK LINKS</div>
              {navLinks.map(l => (
                <div key={l.path} style={{ marginBottom: '10px' }}><Link to={l.path} style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px', textDecoration: 'none' }}>{l.label}</Link></div>
              ))}
            </div>
          </div>
          <div style={{ borderTop: '1px solid rgba(255,255,255,0.06)', paddingTop: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
            <div style={{ color: 'rgba(255,255,255,0.3)', fontSize: '12px' }}>© 2024 Charioteer Blockchain & AI Solutions Pvt. Ltd. All rights reserved.</div>
            <div style={{ color: 'rgba(255,255,255,0.3)', fontSize: '12px' }}>Built with ⚡ by AutoWeb</div>
          </div>
        </div>
      </footer>
    </div>
  );
}