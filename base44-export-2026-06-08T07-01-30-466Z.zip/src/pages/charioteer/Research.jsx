import { Link } from 'react-router-dom';
import CharioteerLayout from './Layout';

export default function CharioteerResearch() {
  return (
    <CharioteerLayout>
      <section style={{ padding: '100px 24px 80px', background: 'linear-gradient(135deg,#030712,#0a0f1e)', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', width: '500px', height: '500px', background: 'rgba(139,92,246,0.07)', borderRadius: '50%', top: '-150px', right: '-100px', filter: 'blur(80px)', pointerEvents: 'none' }} />
        <div style={{ maxWidth: '1200px', margin: '0 auto', position: 'relative', zIndex: 1 }}>
          <div className="badge-label"><span style={{ color: '#a78bfa', fontSize: '12px', fontWeight: 600, letterSpacing: '1px' }}>ACADEMIC SUPPORT</span></div>
          <h1 style={{ fontSize: 'clamp(36px,4.5vw,60px)', fontWeight: 800, letterSpacing: '-2px', marginBottom: '18px' }}>
            Research <span style={{ background: 'linear-gradient(135deg,#a78bfa,#7c3aed)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Helpdesk</span>
          </h1>
          <p style={{ fontSize: '17px', lineHeight: 1.8, maxWidth: '640px', marginBottom: '36px' }}>
            We offer expert support to PhD, M.Tech, MCA, MBA, and LLB candidates through every stage of their academic journey — from synopsis to final submission. Our aim is to simplify your academic journey with reliable, high-quality assistance.
          </p>
          <Link to="/charioteer/contact" className="btn-primary" style={{ background: 'linear-gradient(135deg,#a78bfa,#7c3aed)', color: 'white' }}>Get Research Support →</Link>
        </div>
      </section>

      {/* Services */}
      <section className="section-pad section-mid">
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '56px' }}>
            <h2 style={{ fontSize: 'clamp(28px,3.5vw,44px)', fontWeight: 800, letterSpacing: '-1px' }}>What We <span style={{ background: 'linear-gradient(135deg,#a78bfa,#7c3aed)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Provide</span></h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: '24px' }}>
            {[
              { icon: '📝', title: 'Synopsis & Thesis Writing', desc: 'Professional writing support for all stages of your dissertation — from research proposal to final thesis. We ensure clarity, structure, and academic rigor.', tags: ['Synopsis', 'Thesis', 'Dissertation', 'Research Proposal'] },
              { icon: '📄', title: 'Research Paper Drafting', desc: 'Journal-ready research papers with proper citations, formatting, and language polishing. We support Scopus, SCI, and IEEE indexed publications.', tags: ['Journal Papers', 'Conference Papers', 'IEEE', 'Scopus'] },
              { icon: '🔍', title: 'Plagiarism & AI Detection Removal', desc: 'Comprehensive similarity checking and content refinement to ensure clean, original submissions. We handle both Turnitin and AI detection tools.', tags: ['Turnitin', 'iThenticate', 'AI Detection', 'Paraphrasing'] },
              { icon: '⚙️', title: 'Simulation Work (MATLAB & Python)', desc: 'Technical simulations, data analysis, and algorithm implementation for research papers using MATLAB and Python — the tools academia trusts.', tags: ['MATLAB', 'Python', 'Simulations', 'Data Analysis'] },
            ].map(({ icon, title, desc, tags }) => (
              <div key={title} style={{ background: 'rgba(139,92,246,0.04)', border: '1px solid rgba(139,92,246,0.15)', borderRadius: '20px', padding: '32px' }}>
                <div style={{ fontSize: '32px', marginBottom: '16px' }}>{icon}</div>
                <h3 style={{ color: 'white', fontSize: '18px', fontWeight: 700, marginBottom: '12px' }}>{title}</h3>
                <p style={{ fontSize: '14px', lineHeight: 1.7, marginBottom: '18px' }}>{desc}</p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  {tags.map(t => <span key={t} style={{ background: 'rgba(139,92,246,0.1)', color: '#a78bfa', padding: '3px 12px', borderRadius: '100px', fontSize: '11px', fontWeight: 600 }}>{t}</span>)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Who We Help */}
      <section className="section-pad section-dark">
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '48px' }}>
            <h2 style={{ fontSize: 'clamp(28px,3.5vw,44px)', fontWeight: 800, letterSpacing: '-1px' }}>Who We <span style={{ background: 'linear-gradient(135deg,#a78bfa,#7c3aed)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Help</span></h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: '16px' }}>
            {[['🎓', 'PhD', 'Doctoral Research Scholars'], ['🔧', 'M.Tech', 'Engineering Postgrads'], ['💻', 'MCA', 'CS/IT Candidates'], ['📊', 'MBA', 'Management Students'], ['⚖️', 'LLB', 'Law Candidates']].map(([icon, prog, desc]) => (
              <div key={prog} style={{ background: 'rgba(139,92,246,0.06)', border: '1px solid rgba(139,92,246,0.15)', borderRadius: '16px', padding: '24px', textAlign: 'center' }}>
                <div style={{ fontSize: '30px', marginBottom: '10px' }}>{icon}</div>
                <div style={{ color: 'white', fontWeight: 800, fontSize: '18px', marginBottom: '6px' }}>{prog}</div>
                <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '12px', lineHeight: 1.5 }}>{desc}</div>
              </div>
            ))}
          </div>
          <div style={{ textAlign: 'center', marginTop: '48px' }}>
            <Link to="/charioteer/contact" className="btn-primary" style={{ background: 'linear-gradient(135deg,#a78bfa,#7c3aed)', color: 'white', fontSize: '16px', padding: '14px 36px' }}>Start Your Research Journey →</Link>
          </div>
        </div>
      </section>
    </CharioteerLayout>
  );
}