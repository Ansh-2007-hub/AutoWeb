import { Link } from 'react-router-dom';
import CharioteerLayout from './Layout';

export default function CharioteerTraining() {
  return (
    <CharioteerLayout>
      <section style={{ padding: '100px 24px 80px', background: 'linear-gradient(135deg,#030712,#0a0f1e)', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', width: '500px', height: '500px', background: 'rgba(245,158,11,0.06)', borderRadius: '50%', top: '-150px', right: '-100px', filter: 'blur(80px)', pointerEvents: 'none' }} />
        <div style={{ maxWidth: '1200px', margin: '0 auto', position: 'relative', zIndex: 1, textAlign: 'center' }}>
          <div className="badge-label" style={{ justifyContent: 'center' }}><span>PROGRAMS</span></div>
          <h1 style={{ fontSize: 'clamp(36px,4.5vw,60px)', fontWeight: 800, letterSpacing: '-2px', marginBottom: '18px' }}>Training <span className="grad-text">Programs</span></h1>
          <p style={{ fontSize: '17px', lineHeight: 1.8, maxWidth: '600px', margin: '0 auto' }}>Industry-relevant courses designed for students, professionals, and researchers looking to master future technologies — online and offline.</p>
        </div>
      </section>

      {/* Main Programs */}
      <section className="section-pad section-mid">
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: '24px', marginBottom: '40px' }}>
            {[
              { icon: '⛓️', title: 'Blockchain & Web3', badge: 'MOST POPULAR', badgeColor: '#f59e0b', badgeBg: 'rgba(245,158,11,0.12)', border: 'rgba(245,158,11,0.2)', modules: ['Blockchain Fundamentals', 'Smart Contract Development', 'DeFi & NFTs', 'Web3 dApp Building', 'Crypto & Tokenomics', 'Hyperledger & Enterprise Blockchain'], mode: 'Online & Offline' },
              { icon: '🤖', title: 'Artificial Intelligence', badge: 'TRENDING', badgeColor: '#fb923c', badgeBg: 'rgba(249,115,22,0.12)', border: 'rgba(249,115,22,0.2)', modules: ['Python for AI/ML', 'Machine Learning Algorithms', 'Deep Learning & Neural Networks', 'Natural Language Processing', 'Computer Vision', 'AI for Business Automation'], mode: 'Online & Offline' },
              { icon: '🌐', title: 'Metaverse & VR', badge: 'NEW', badgeColor: '#a78bfa', badgeBg: 'rgba(139,92,246,0.12)', border: 'rgba(139,92,246,0.2)', modules: ['Metaverse Fundamentals', 'Virtual World Building', 'AR/VR Development', 'Digital Twin Concepts', 'Metaverse Business Models', 'Web3 + Metaverse Integration'], mode: 'Online' },
              { icon: '📊', title: 'Digital Marketing', badge: 'BEGINNER FRIENDLY', badgeColor: '#4ade80', badgeBg: 'rgba(34,197,94,0.12)', border: 'rgba(34,197,94,0.2)', modules: ['SEO & SEM Mastery', 'Social Media Marketing', 'Content Marketing Strategy', 'Email & Performance Marketing', 'Google Ads & Analytics', 'Brand Building & Growth'], mode: 'Online & Offline' },
            ].map(({ icon, title, badge, badgeColor, badgeBg, border, modules, mode }) => (
              <div key={title} style={{ background: 'rgba(255,255,255,0.02)', border: `1px solid ${border}`, borderRadius: '20px', padding: '32px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
                  <div style={{ fontSize: '36px' }}>{icon}</div>
                  <span style={{ background: badgeBg, color: badgeColor, padding: '4px 12px', borderRadius: '100px', fontSize: '11px', fontWeight: 700 }}>{badge}</span>
                </div>
                <h3 style={{ color: 'white', fontSize: '20px', fontWeight: 700, marginBottom: '16px' }}>{title}</h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '20px' }}>
                  {modules.map(m => (
                    <div key={m} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <div style={{ width: '5px', height: '5px', background: badgeColor, borderRadius: '50%', flexShrink: 0 }} />
                      <span style={{ color: 'rgba(255,255,255,0.6)', fontSize: '13px' }}>{m}</span>
                    </div>
                  ))}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '16px', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                  <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: '12px' }}>📡 {mode}</span>
                  <Link to="/charioteer/contact" style={{ color: badgeColor, fontSize: '13px', fontWeight: 700, textDecoration: 'none' }}>Enroll →</Link>
                </div>
              </div>
            ))}
          </div>

          {/* Industrial Training */}
          <div style={{ background: 'linear-gradient(135deg,rgba(245,158,11,0.07),rgba(249,115,22,0.04))', border: '1px solid rgba(245,158,11,0.15)', borderRadius: '20px', padding: '36px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '24px' }}>
            <div>
              <div className="badge-label"><span>INDUSTRIAL TRAINING</span></div>
              <h3 style={{ color: 'white', fontSize: '22px', fontWeight: 700, marginBottom: '10px' }}>Internships & Industrial Training</h3>
              <p style={{ fontSize: '14px', lineHeight: 1.7, maxWidth: '500px' }}>Real-world project experience with expert mentorship in Python · MATLAB · Java · .NET · PHP. Build job-ready skills that employers demand.</p>
            </div>
            <Link to="/charioteer/contact" className="btn-primary">Apply Now →</Link>
          </div>
        </div>
      </section>

      {/* Specializations */}
      <section className="section-pad section-dark">
        <div style={{ maxWidth: '1200px', margin: '0 auto', textAlign: 'center' }}>
          <h2 style={{ fontSize: 'clamp(28px,3.5vw,44px)', fontWeight: 800, letterSpacing: '-1px', marginBottom: '14px' }}>We Specialize In</h2>
          <p style={{ marginBottom: '48px', fontSize: '16px' }}>Three core technology domains where Charioteer has built deep expertise</p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '24px' }}>
            {[['⛓️', 'Blockchain', 'Deep expertise in distributed ledger, smart contracts, and decentralized applications across enterprise and public chains.', '#f59e0b'],
              ['🤖', 'Artificial Intelligence', 'From fundamentals to advanced deep learning — practical AI skills for real-world automation and decision-making.', '#fb923c'],
              ['💻', 'Computer Languages', 'Python, Java, .NET, PHP, MATLAB — industry-standard languages taught through hands-on project work.', '#4ade80']].map(([icon, title, desc, color]) => (
              <div key={title} style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: '20px', padding: '36px', textAlign: 'center' }}>
                <div style={{ fontSize: '40px', marginBottom: '16px' }}>{icon}</div>
                <h3 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '12px', color }}>
                  {title}
                </h3>
                <p style={{ fontSize: '14px', lineHeight: 1.7 }}>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </CharioteerLayout>
  );
}