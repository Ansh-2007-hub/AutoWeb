import { useState } from 'react';
import CharioteerLayout from './Layout';

export default function CharioteerContact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', program: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <CharioteerLayout>
      <section style={{ padding: '100px 24px 80px', background: 'linear-gradient(135deg,#030712,#0a0f1e)', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', width: '500px', height: '500px', background: 'rgba(245,158,11,0.06)', borderRadius: '50%', top: '-150px', right: '-100px', filter: 'blur(80px)', pointerEvents: 'none' }} />
        <div style={{ maxWidth: '1200px', margin: '0 auto', position: 'relative', zIndex: 1, textAlign: 'center' }}>
          <div className="badge-label" style={{ justifyContent: 'center' }}><span>GET IN TOUCH</span></div>
          <h1 style={{ fontSize: 'clamp(36px,4.5vw,60px)', fontWeight: 800, letterSpacing: '-2px', marginBottom: '18px' }}>Contact <span className="grad-text">Charioteer</span></h1>
          <p style={{ fontSize: '17px', lineHeight: 1.8, maxWidth: '560px', margin: '0 auto' }}>Ready to transform your career? Reach out to us for training, research support, or any queries. Our experts are here to help.</p>
        </div>
      </section>

      <section className="section-pad section-mid">
        <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '64px', alignItems: 'start' }}>
          {/* Contact Info */}
          <div>
            <h2 style={{ fontSize: '28px', fontWeight: 800, marginBottom: '28px' }}>Let's <span className="grad-text">Connect</span></h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', marginBottom: '36px' }}>
              {[['🌐', 'Website', 'charioteer.io', 'https://charioteer.io'],
                ['📍', 'Location', 'India', null],
                ['🎓', 'Programs', 'Blockchain · AI · Metaverse · Digital Marketing', null],
                ['🔬', 'Research Support', 'PhD · M.Tech · MCA · MBA · LLB', null]].map(([icon, label, value, href]) => (
                <div key={label} style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
                  <div style={{ width: '42px', height: '42px', background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.15)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px', flexShrink: 0 }}>{icon}</div>
                  <div>
                    <div style={{ color: 'rgba(255,255,255,0.45)', fontSize: '12px', fontWeight: 600, letterSpacing: '0.5px', marginBottom: '4px' }}>{label}</div>
                    {href ? <a href={href} target="_blank" rel="noreferrer" style={{ color: '#f59e0b', fontSize: '15px', fontWeight: 600, textDecoration: 'none' }}>{value}</a>
                      : <div style={{ color: 'white', fontSize: '15px', fontWeight: 600 }}>{value}</div>}
                  </div>
                </div>
              ))}
            </div>

            <div style={{ background: 'linear-gradient(135deg,rgba(245,158,11,0.07),rgba(249,115,22,0.04))', border: '1px solid rgba(245,158,11,0.12)', borderRadius: '16px', padding: '24px' }}>
              <h3 style={{ color: 'white', fontSize: '16px', fontWeight: 700, marginBottom: '12px' }}>Quick Response Promise</h3>
              <p style={{ fontSize: '13px', lineHeight: 1.7, marginBottom: '0' }}>Our team typically responds within 24 hours. For urgent queries about research deadlines or enrollment, mention it in your message.</p>
            </div>
          </div>

          {/* Form */}
          <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: '24px', padding: '36px' }}>
            {submitted ? (
              <div style={{ textAlign: 'center', padding: '40px 0' }}>
                <div style={{ fontSize: '48px', marginBottom: '16px' }}>✅</div>
                <h3 style={{ color: 'white', fontSize: '22px', fontWeight: 700, marginBottom: '12px' }}>Message Sent!</h3>
                <p style={{ fontSize: '14px', lineHeight: 1.7 }}>Thank you for reaching out to Charioteer. Our team will get back to you within 24 hours.</p>
                <button onClick={() => setSubmitted(false)} style={{ marginTop: '24px', background: 'linear-gradient(135deg,#f59e0b,#f97316)', color: '#030712', border: 'none', padding: '10px 24px', borderRadius: '9px', fontWeight: 700, fontSize: '14px', cursor: 'pointer', fontFamily: 'inherit' }}>Send Another</button>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <h3 style={{ color: 'white', fontSize: '20px', fontWeight: 700, marginBottom: '24px' }}>Send us a Message</h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                  {[['name', 'Full Name', 'Your full name'], ['email', 'Email Address', 'your@email.com']].map(([field, label, placeholder]) => (
                    <div key={field}>
                      <label style={{ color: 'rgba(255,255,255,0.55)', fontSize: '12px', fontWeight: 600, display: 'block', marginBottom: '6px', letterSpacing: '0.5px' }}>{label}</label>
                      <input type={field === 'email' ? 'email' : 'text'} placeholder={placeholder} required value={form[field]} onChange={e => setForm({ ...form, [field]: e.target.value })}
                        style={{ width: '100%', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '10px', padding: '11px 14px', color: 'white', fontSize: '14px', outline: 'none', fontFamily: 'inherit', boxSizing: 'border-box' }} />
                    </div>
                  ))}
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                  <div>
                    <label style={{ color: 'rgba(255,255,255,0.55)', fontSize: '12px', fontWeight: 600, display: 'block', marginBottom: '6px', letterSpacing: '0.5px' }}>Phone Number</label>
                    <input type="tel" placeholder="+91 XXXXX XXXXX" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })}
                      style={{ width: '100%', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '10px', padding: '11px 14px', color: 'white', fontSize: '14px', outline: 'none', fontFamily: 'inherit', boxSizing: 'border-box' }} />
                  </div>
                  <div>
                    <label style={{ color: 'rgba(255,255,255,0.55)', fontSize: '12px', fontWeight: 600, display: 'block', marginBottom: '6px', letterSpacing: '0.5px' }}>Interested In</label>
                    <select value={form.program} onChange={e => setForm({ ...form, program: e.target.value })}
                      style={{ width: '100%', background: '#0a0f1e', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '10px', padding: '11px 14px', color: form.program ? 'white' : 'rgba(255,255,255,0.3)', fontSize: '14px', outline: 'none', fontFamily: 'inherit', boxSizing: 'border-box' }}>
                      <option value="">Select a program</option>
                      <option value="blockchain">Blockchain & Web3</option>
                      <option value="ai">Artificial Intelligence</option>
                      <option value="metaverse">Metaverse</option>
                      <option value="digital-marketing">Digital Marketing</option>
                      <option value="industrial">Industrial Training</option>
                      <option value="research">Research Helpdesk</option>
                    </select>
                  </div>
                </div>
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ color: 'rgba(255,255,255,0.55)', fontSize: '12px', fontWeight: 600, display: 'block', marginBottom: '6px', letterSpacing: '0.5px' }}>Message</label>
                  <textarea placeholder="Tell us about your requirements or any questions..." rows={4} value={form.message} onChange={e => setForm({ ...form, message: e.target.value })}
                    style={{ width: '100%', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '10px', padding: '11px 14px', color: 'white', fontSize: '14px', outline: 'none', fontFamily: 'inherit', resize: 'vertical', boxSizing: 'border-box' }} />
                </div>
                <button type="submit" className="btn-primary" style={{ width: '100%', border: 'none', cursor: 'pointer', fontSize: '15px', padding: '13px', textAlign: 'center', borderRadius: '10px' }}>
                  Send Message →
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </CharioteerLayout>
  );
}