import { Link } from 'react-router-dom';
import CharioteerLayout from './Layout';

export default function CharioteerServices() {
  return (
    <CharioteerLayout>
      <section style={{ padding: '100px 24px 80px', background: 'linear-gradient(135deg,#030712,#0a0f1e)', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', width: '500px', height: '500px', background: 'rgba(245,158,11,0.06)', borderRadius: '50%', top: '-150px', right: '-100px', filter: 'blur(80px)', pointerEvents: 'none' }} />
        <div style={{ maxWidth: '1200px', margin: '0 auto', position: 'relative', zIndex: 1, textAlign: 'center' }}>
          <div className="badge-label" style={{ justifyContent: 'center' }}><span>WHAT WE OFFER</span></div>
          <h1 style={{ fontSize: 'clamp(36px,4.5vw,60px)', fontWeight: 800, letterSpacing: '-2px', marginBottom: '18px' }}>Our Core <span className="grad-text">Services</span></h1>
          <p style={{ fontSize: '17px', lineHeight: 1.8, maxWidth: '600px', margin: '0 auto' }}>From hands-on training to academic research support — we cover the full spectrum of tech education and professional development.</p>
        </div>
      </section>

      {/* Service 1 */}
      <section className="section-pad section-mid">
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '64px', alignItems: 'center', marginBottom: '80px' }}>
            <div>
              <div className="badge-label"><span>SERVICE 01</span></div>
              <h2 style={{ fontSize: 'clamp(28px,3vw,40px)', fontWeight: 800, letterSpacing: '-1px', marginBottom: '16px' }}>Online & Offline <span className="grad-text">Training</span></h2>
              <p style={{ fontSize: '15px', lineHeight: 1.8, marginBottom: '24px' }}>We provide both online and offline training in cutting-edge fields — giving you the flexibility to learn from anywhere or in-person at our centers across India.</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '28px' }}>
                {['Blockchain & Web3 Technology', 'Artificial Intelligence & Machine Learning', 'Metaverse & Virtual Reality', 'Digital Marketing & SEO'].map(item => (
                  <div key={item} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <div style={{ width: '20px', height: '20px', background: 'linear-gradient(135deg,#f59e0b,#f97316)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', flexShrink: 0 }}>✓</div>
                    <span style={{ color: 'rgba(255,255,255,0.75)', fontSize: '14px' }}>{item}</span>
                  </div>
                ))}
              </div>
              <Link to="/charioteer/training" className="btn-primary">View Training Programs →</Link>
            </div>
            <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(245,158,11,0.12)', borderRadius: '24px', padding: '32px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                {[['⛓️', 'Blockchain', '#f59e0b'], ['🤖', 'AI / ML', '#fb923c'], ['🌐', 'Metaverse', '#a78bfa'], ['📊', 'Digital Mktg', '#4ade80']].map(([icon, label, color]) => (
                  <div key={label} style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: '14px', padding: '20px', textAlign: 'center' }}>
                    <div style={{ fontSize: '28px', marginBottom: '8px' }}>{icon}</div>
                    <div style={{ color: color, fontWeight: 700, fontSize: '13px' }}>{label}</div>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: '14px', background: 'rgba(245,158,11,0.06)', border: '1px solid rgba(245,158,11,0.12)', borderRadius: '12px', padding: '16px', textAlign: 'center' }}>
                <div style={{ color: '#f59e0b', fontWeight: 700, fontSize: '13px' }}>Both Online & Offline</div>
                <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '12px', marginTop: '4px' }}>Flexible learning modes for your convenience</div>
              </div>
            </div>
          </div>

          {/* Service 2 */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '64px', alignItems: 'center', marginBottom: '80px', direction: 'rtl' }}>
            <div style={{ direction: 'ltr' }}>
              <div className="badge-label"><span>SERVICE 02</span></div>
              <h2 style={{ fontSize: 'clamp(28px,3vw,40px)', fontWeight: 800, letterSpacing: '-1px', marginBottom: '16px' }}>Research <span style={{ background: 'linear-gradient(135deg,#a78bfa,#7c3aed)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Helpdesk</span></h2>
              <p style={{ fontSize: '15px', lineHeight: 1.8, marginBottom: '24px' }}>We offer expert support to PhD, M.Tech, MCA, MBA, and LLB candidates — simplifying your academic journey with reliable, high-quality assistance at every stage.</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '28px' }}>
                {['Synopsis & Thesis/Dissertation Writing', 'Research Paper Drafting & Publishing', 'Similarity & AI Plagiarism Removal', 'Simulation Work (MATLAB & Python)'].map(item => (
                  <div key={item} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <div style={{ width: '20px', height: '20px', background: 'linear-gradient(135deg,#a78bfa,#7c3aed)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', flexShrink: 0, color: 'white' }}>✓</div>
                    <span style={{ color: 'rgba(255,255,255,0.75)', fontSize: '14px' }}>{item}</span>
                  </div>
                ))}
              </div>
              <Link to="/charioteer/research" className="btn-primary" style={{ background: 'linear-gradient(135deg,#a78bfa,#7c3aed)', color: 'white' }}>Research Support →</Link>
            </div>
            <div style={{ direction: 'ltr', background: 'rgba(139,92,246,0.04)', border: '1px solid rgba(139,92,246,0.15)', borderRadius: '24px', padding: '32px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                {[['🎓', 'PhD', 'Doctoral Research'], ['🔧', 'M.Tech', 'Engineering Research'], ['💻', 'MCA', 'CS/IT Projects'], ['📊', 'MBA', 'Business Studies'], ['⚖️', 'LLB', 'Legal Research'], ['📝', 'Paper', 'Journal Writing']].map(([icon, label, sub]) => (
                  <div key={label} style={{ background: 'rgba(139,92,246,0.08)', border: '1px solid rgba(139,92,246,0.15)', borderRadius: '12px', padding: '16px', textAlign: 'center' }}>
                    <div style={{ fontSize: '22px', marginBottom: '6px' }}>{icon}</div>
                    <div style={{ color: 'white', fontWeight: 700, fontSize: '13px' }}>{label}</div>
                    <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '11px', marginTop: '2px' }}>{sub}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Service 3 */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '64px', alignItems: 'center' }}>
            <div>
              <div className="badge-label"><span>SERVICE 03</span></div>
              <h2 style={{ fontSize: 'clamp(28px,3vw,40px)', fontWeight: 800, letterSpacing: '-1px', marginBottom: '16px' }}>Industrial Training <span style={{ background: 'linear-gradient(135deg,#4ade80,#16a34a)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>(Internships)</span></h2>
              <p style={{ fontSize: '15px', lineHeight: 1.8, marginBottom: '24px' }}>Our experts impart industrial training (internship) on industry-relevant platforms. Designed to build real-world skills through hands-on projects and expert guidance.</p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', marginBottom: '28px' }}>
                {['Python', 'MATLAB', '.NET', 'Java', 'PHP'].map(tech => (
                  <span key={tech} style={{ background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.2)', color: '#4ade80', padding: '6px 16px', borderRadius: '100px', fontSize: '13px', fontWeight: 600 }}>{tech}</span>
                ))}
              </div>
              <Link to="/charioteer/contact" className="btn-primary" style={{ background: 'linear-gradient(135deg,#4ade80,#16a34a)', color: '#030712' }}>Apply for Internship →</Link>
            </div>
            <div style={{ background: 'rgba(34,197,94,0.04)', border: '1px solid rgba(34,197,94,0.15)', borderRadius: '24px', padding: '32px' }}>
              {[['Real Project Experience', '100%', 'Work on actual industry projects'], ['Job Readiness', 'Fast Track', 'Accelerated skill building'], ['Expert Mentors', 'Industry Pros', 'Learn from real practitioners'], ['Certificate', 'Provided', 'Industry-recognized certification']].map(([title, val, desc]) => (
                <div key={title} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 0', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                  <div>
                    <div style={{ color: 'white', fontWeight: 700, fontSize: '14px' }}>{title}</div>
                    <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '12px', marginTop: '2px' }}>{desc}</div>
                  </div>
                  <div style={{ color: '#4ade80', fontWeight: 800, fontSize: '13px', background: 'rgba(34,197,94,0.1)', padding: '4px 12px', borderRadius: '100px' }}>{val}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </CharioteerLayout>
  );
}