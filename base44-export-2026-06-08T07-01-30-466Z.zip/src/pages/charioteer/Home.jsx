import { Link } from 'react-router-dom';
import CharioteerLayout from './Layout';

export default function CharioteerHome() {
  return (
    <CharioteerLayout>
      {/* Hero */}
      <section style={{ minHeight: '100vh', background: 'linear-gradient(135deg,#030712 0%,#0a0f1e 60%,#030712 100%)', display: 'flex', alignItems: 'center', position: 'relative', overflow: 'hidden', padding: '80px 24px' }}>
        <div style={{ position: 'absolute', width: '700px', height: '700px', background: 'rgba(245,158,11,0.06)', borderRadius: '50%', top: '-200px', right: '-200px', filter: 'blur(80px)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', width: '500px', height: '500px', background: 'rgba(249,115,22,0.05)', borderRadius: '50%', bottom: '-150px', left: '-100px', filter: 'blur(70px)', pointerEvents: 'none' }} />
        <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '60px', alignItems: 'center', position: 'relative', zIndex: 1 }}>
          <div>
            <div className="badge-label"><span>INDIA'S LEADING BLOCKCHAIN & AI INSTITUTE</span></div>
            <h1 style={{ fontSize: 'clamp(40px,5vw,66px)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-2px', marginBottom: '22px' }}>
              Empowering Futures with <span className="grad-text">Blockchain & AI</span>
            </h1>
            <p style={{ fontSize: '17px', lineHeight: 1.8, marginBottom: '36px', maxWidth: '480px' }}>
              Charioteer Blockchain & AI Solutions Pvt. Ltd. trains professionals, researchers, and students in Blockchain, AI, Web3, Metaverse & Digital Marketing — with real-world, industry-aligned programs.
            </p>
            <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
              <Link to="/charioteer/training" className="btn-primary">Explore Programs →</Link>
              <Link to="/charioteer/contact" className="btn-ghost">Talk to an Expert</Link>
            </div>
            <div style={{ display: 'flex', gap: '40px', marginTop: '48px', flexWrap: 'wrap' }}>
              {[['1B+', 'Vision: People by 2030'], ['5+', 'Tech Domains'], ['PhD', 'Research Support']].map(([v, l]) => (
                <div key={l}>
                  <div style={{ color: '#f59e0b', fontSize: '30px', fontWeight: 800 }}>{v}</div>
                  <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px', marginTop: '4px' }}>{l}</div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(245,158,11,0.12)', borderRadius: '24px', padding: '28px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                {[['⛓️', 'Blockchain', 'Web3 & DeFi', 'rgba(245,158,11,0.08)', 'rgba(245,158,11,0.15)'],
                  ['🤖', 'AI & ML', 'Deep Learning', 'rgba(249,115,22,0.08)', 'rgba(249,115,22,0.15)'],
                  ['🌐', 'Metaverse', 'Virtual Worlds', 'rgba(139,92,246,0.08)', 'rgba(139,92,246,0.15)'],
                  ['📊', 'Digital Mktg', 'SEO & Growth', 'rgba(34,197,94,0.08)', 'rgba(34,197,94,0.15)']].map(([icon, title, sub, bg, border]) => (
                  <div key={title} style={{ background: bg, border: `1px solid ${border}`, borderRadius: '14px', padding: '18px', textAlign: 'center' }}>
                    <div style={{ fontSize: '28px', marginBottom: '8px' }}>{icon}</div>
                    <div style={{ color: 'white', fontWeight: 700, fontSize: '14px' }}>{title}</div>
                    <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '11px', marginTop: '3px' }}>{sub}</div>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: '14px', background: 'rgba(245,158,11,0.06)', border: '1px solid rgba(245,158,11,0.1)', borderRadius: '12px', padding: '14px', display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ width: '38px', height: '38px', background: 'linear-gradient(135deg,#f59e0b,#f97316)', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '18px', flexShrink: 0 }}>🎓</div>
                <div>
                  <div style={{ color: 'white', fontWeight: 700, fontSize: '13px' }}>Industrial Training Available</div>
                  <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '12px', marginTop: '2px' }}>Python · MATLAB · Java · .NET · PHP</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="section-pad section-mid">
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '56px' }}>
            <div className="badge-label" style={{ justifyContent: 'center' }}><span>WHY CHARIOTEER</span></div>
            <h2 style={{ fontSize: 'clamp(32px,4vw,48px)', fontWeight: 800, letterSpacing: '-1.5px' }}>Why <span className="grad-text">Choose Us?</span></h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '22px' }}>
            {[['🛠️', 'Practical Skills', 'Hands-on, project-based learning — not just theory. You build real things from day one.'],
              ['🚀', 'Fast Results', 'Accelerated programs designed to get you job-ready or research-ready quickly.'],
              ['📈', 'Career Growth', 'Future-ready skills aligned with industry demand in Blockchain, AI, and Web3.'],
              ['🤝', 'Corporate Trust', 'Trusted by universities, investors, and industry leaders across India.'],
              ['🌍', 'Global Vision', 'Training 1 billion people in ethical Blockchain & Web3 by 2030.'],
              ['📚', 'Real Learning', 'Expert instructors, live sessions, and industry-aligned curriculum.']].map(([icon, title, desc]) => (
              <div key={title} className="card" style={{ textAlign: 'center' }}>
                <div style={{ width: '56px', height: '56px', background: 'linear-gradient(135deg,rgba(245,158,11,0.18),rgba(249,115,22,0.1))', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '24px', margin: '0 auto 18px' }}>{icon}</div>
                <h3 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '10px' }}>{title}</h3>
                <p style={{ fontSize: '13px', lineHeight: 1.7 }}>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Industries */}
      <section className="section-pad section-dark">
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '56px' }}>
            <div className="badge-label" style={{ justifyContent: 'center' }}><span>INDUSTRIES WE SERVE</span></div>
            <h2 style={{ fontSize: 'clamp(32px,4vw,48px)', fontWeight: 800, letterSpacing: '-1.5px' }}>Sectors We <span className="grad-text">Empower</span></h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: '16px' }}>
            {[['⛓️', 'Blockchain Industry'], ['🎓', 'Training Institutions'], ['🔬', 'Universities & Research'], ['📚', 'Publishing Houses'], ['☁️', 'Cloud & AI Services']].map(([icon, name]) => (
              <div key={name} style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: '16px', padding: '24px 16px', textAlign: 'center' }}>
                <div style={{ fontSize: '28px', marginBottom: '10px' }}>{icon}</div>
                <div style={{ color: 'white', fontWeight: 600, fontSize: '13px' }}>{name}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: '80px 24px', background: 'linear-gradient(135deg,rgba(245,158,11,0.08),rgba(249,115,22,0.05))', borderTop: '1px solid rgba(245,158,11,0.12)', borderBottom: '1px solid rgba(245,158,11,0.12)' }}>
        <div style={{ maxWidth: '700px', margin: '0 auto', textAlign: 'center' }}>
          <h2 style={{ fontSize: 'clamp(28px,3.5vw,42px)', fontWeight: 800, letterSpacing: '-1px', marginBottom: '16px' }}>Ready to Start Your <span className="grad-text">Journey?</span></h2>
          <p style={{ fontSize: '16px', lineHeight: 1.7, marginBottom: '32px' }}>Join thousands of professionals and students who have transformed their careers with Charioteer's industry-leading programs.</p>
          <div style={{ display: 'flex', gap: '14px', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link to="/charioteer/contact" className="btn-primary">Enroll Now →</Link>
            <Link to="/charioteer/services" className="btn-ghost">View All Services</Link>
          </div>
        </div>
      </section>
    </CharioteerLayout>
  );
}