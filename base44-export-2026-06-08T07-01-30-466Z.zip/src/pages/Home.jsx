const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useCallback } from 'react';
import GeneratingTerminal from '../components/GeneratingTerminal';
import CreateAccountModal from '../components/CreateAccountModal';
import { useQueryClient } from '@tanstack/react-query';

import Sidebar from '../components/Sidebar';
import PromptInput from '../components/PromptInput';
import PreviewArea from '../components/PreviewArea';
import SectionsPanel from '../components/SectionsPanel';
import EditorToolbar from '../components/EditorToolbar';
import CodeView from '../components/CodeView';
import { toast } from 'sonner';
import { useAuth } from '@/lib/AuthContext';

export default function Home() {
  const [activeGen, setActiveGen] = useState(null);
  const [sections, setSections] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatingPrompt, setGeneratingPrompt] = useState('');
  const [regeneratingId, setRegeneratingId] = useState(null);
  const [view, setView] = useState('sections');
  const [viewport, setViewport] = useState('desktop');
  const [accountModal, setAccountModal] = useState({ open: false, plan: '' });
  const [activeSection, setActiveSection] = useState('');
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const generateWebsite = useCallback(async (prompt) => {
    setIsGenerating(true);
    setGeneratingPrompt(prompt);

    // Step 1: Research the company/topic from the web
    let companyContext = '';
    try {
      const research = await db.integrations.Core.InvokeLLM({
        prompt: `Research this website request and extract key details: "${prompt}"

If this mentions a specific company or brand, find:
- What the company does (products/services)
- Their tagline or brand voice
- Key features or selling points
- Target audience
- Any notable facts or achievements
- Pricing model if applicable

If it's a generic/fictional site, just describe the ideal content for it.
Return a concise paragraph of research findings.`,
        add_context_from_internet: true,
        model: 'gemini_3_flash',
      });
      companyContext = research || '';
    } catch (e) {
      // Research failed, continue without it
    }

    const result = await db.integrations.Core.InvokeLLM({
      prompt: `You are a world-class UI/UX designer. Generate a STUNNING, production-quality website for: "${prompt}"

${companyContext ? `RESEARCHED COMPANY/BRAND CONTEXT (use this for real copy, accurate descriptions, and brand-accurate design):
${companyContext}
` : ''}

CRITICAL DESIGN RULES:
1. NAVIGATION: Sticky top, backdrop-blur-md bg-black/80 or white/80, logo left, links center, CTA button right with hover effects
2. HERO: min-h-screen flex items-center, MASSIVE headline (text-6xl xl:text-8xl font-black), dramatic gradient background or dark/light bold design, decorative blurred gradient orbs (absolute positioned divs with blur-3xl opacity-30), dual CTA buttons
3. FONTS: Add <style>@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Sora:wght@300;400;600;800&display=swap');</style> in the navigation section only. Use font-[Space_Grotesk] or inline style fontFamily
4. IMAGES: Use real Unsplash photos https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=1200&q=80 (use REAL specific photo IDs matching the content theme)
5. COPY: Write REAL compelling marketing copy — no Lorem ipsum ever
6. ANIMATIONS: Add CSS keyframe animations for hero elements, floating shapes, gradient shifts
7. CARDS: Always hover:scale-105 hover:shadow-2xl transition-all duration-300
8. GRADIENTS: Use gradient text: bg-gradient-to-r from-[color] to-[color] bg-clip-text text-transparent
9. SPACING: py-24 or py-32 between sections. Generous padding
10. PRICING: 3 tiers, middle highlighted with ring-2 ring-primary scale-105. Real feature lists. "Start Free" CTA on free tier
11. NO video tags, NO iframes, NO external scripts except fonts
12. Each section must be a self-contained <section> or <nav> or <footer> tag

Return JSON: title (string) + sections array with id/name/html/order. Generate 6-8 sections.
Make it look like a $50,000 agency website. Be bold, creative, and unique.`,
      response_json_schema: {
        type: "object",
        properties: {
          title: { type: "string" },
          sections: {
            type: "array",
            items: {
              type: "object",
              properties: {
                id: { type: "string" },
                name: { type: "string" },
                html: { type: "string" },
                order: { type: "number" }
              }
            }
          }
        }
      },
      model: "gemini_3_flash"
    });

    const gen = await db.entities.Generation.create({
      title: result.title || prompt.slice(0, 50),
      description: prompt,
      sections: result.sections,
      section_count: result.sections.length,
    });

    setSections(result.sections);
    setActiveGen(gen);
    queryClient.invalidateQueries({ queryKey: ['generations'] });
    setIsGenerating(false);
    setGeneratingPrompt('');
  }, [queryClient]);

  const regenerateSection = useCallback(async (sectionId, editPrompt) => {
    setRegeneratingId(sectionId);
    const section = sections.find((s) => s.id === sectionId);
    const result = await db.integrations.Core.InvokeLLM({
      prompt: `You are a web designer. Regenerate the "${section.name}" section of a website titled "${activeGen?.title}".
${editPrompt ? `User wants: ${editPrompt}` : 'Make it different and better.'}
Current HTML: ${section.html}

Return a JSON with "html" containing the new Tailwind CSS HTML for this section. Make it stunning and production-ready.`,
      response_json_schema: {
        type: "object",
        properties: { html: { type: "string" } }
      },
      model: "gemini_3_flash"
    });

    const updated = sections.map((s) =>
      s.id === sectionId ? { ...s, html: result.html } : s
    );
    setSections(updated);

    if (activeGen) {
      await db.entities.Generation.update(activeGen.id, { sections: updated });
    }
    setRegeneratingId(null);
  }, [sections, activeGen]);

  const handlePricingUpdate = useCallback(async (sectionId, newHtml, pricingData) => {
    const updated = sections.map((s) =>
      s.id === sectionId ? { ...s, html: newHtml, _pricingData: pricingData } : s
    );
    setSections(updated);
    if (activeGen) {
      await db.entities.Generation.update(activeGen.id, { sections: updated });
    }
  }, [sections, activeGen]);

  const reorderSections = useCallback(async (reordered) => {
    setSections(reordered);
    if (activeGen) {
      await db.entities.Generation.update(activeGen.id, { sections: reordered });
    }
  }, [activeGen]);

  const deleteSection = useCallback(async (sectionId) => {
    const updated = sections.filter((s) => s.id !== sectionId);
    setSections(updated);
    if (activeGen) {
      await db.entities.Generation.update(activeGen.id, {
        sections: updated,
        section_count: updated.length,
      });
    }
  }, [sections, activeGen]);

  const handleSelect = (gen) => {
    setActiveGen(gen);
    setSections(gen.sections || []);
  };

  const handleNew = () => {
    setActiveGen(null);
    setSections([]);
  };

  const exportHTML = () => {
    const allHtml = sections
      .sort((a, b) => (a.order || 0) - (b.order || 0))
      .map((s) => s.html)
      .join('\n');
    const full = `<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0">\n<title>${activeGen?.title || 'My Website'}</title>\n<script src="https://cdn.tailwindcss.com"><\/script>\n<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">\n<style>body{font-family:'Inter',sans-serif;}</style>\n</head>\n<body>\n${allHtml}\n</body>\n</html>`;
    const blob = new Blob([full], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(activeGen?.title || 'website').replace(/\s+/g, '-').toLowerCase()}.html`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('HTML file downloaded!');
  };

  const launchSite = () => {
    if (activeGen?.id) {
      window.open(`/preview/${activeGen.id}`, '_blank');
    } else {
      const allHtml = sections.sort((a, b) => (a.order || 0) - (b.order || 0)).map((s) => s.html).join('\n');
      const full = `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>${activeGen?.title || 'My Website'}</title><script src="https://cdn.tailwindcss.com"><\/script><link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet"><style>body{font-family:'Inter',sans-serif;}</style></head><body>${allHtml}</body></html>`;
      const w = window.open('', '_blank');
      w.document.write(full);
      w.document.close();
    }
  };

  const isEditing = activeGen || sections.length > 0;

  return (
    <div className="h-screen flex bg-background text-foreground font-sans overflow-hidden">
      <Sidebar activeId={activeGen?.id} onSelect={handleSelect} onNew={handleNew} />

      <div className="flex-1 flex flex-col min-w-0">
        {isEditing && (
          <EditorToolbar
            title={activeGen?.title || 'Untitled'}
            view={view}
            onViewChange={setView}
            viewport={viewport}
            onViewportChange={setViewport}
            onExportHTML={exportHTML}
            onLaunch={launchSite}
            generationId={activeGen?.id}
            currentUser={user}
            activeSection={activeSection}
          />
        )}

        <div className="flex-1 flex min-h-0">
          {!isEditing && !isGenerating ? (
            <PromptInput onGenerate={generateWebsite} isGenerating={isGenerating} />
          ) : (
            <>
              {view === 'sections' ? (
                <PreviewArea sections={sections} onCtaClick={(text, plan) => setAccountModal({ open: true, plan })} viewport={viewport} />
              ) : (
                <CodeView sections={sections} />
              )}
              {view === 'sections' && (
                <SectionsPanel
                  sections={sections}
                  onRegenerate={regenerateSection}
                  onDelete={deleteSection}
                  onPricingUpdate={handlePricingUpdate}
                  regeneratingId={regeneratingId}
                  onReorder={reorderSections}
                />
              )}
            </>
          )}

          {isGenerating && !isEditing && (
            <GeneratingTerminal prompt={generatingPrompt} />
          )}
        </div>
      </div>
      <CreateAccountModal
        isOpen={accountModal.open}
        onClose={() => setAccountModal({ open: false, plan: '' })}
        planName={accountModal.plan}
      />
    </div>
  );
}