const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';

export default function PublicPreview() {
  const { id } = useParams();
  const [html, setHtml] = useState('');
  const [title, setTitle] = useState('');
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!id) return;
    db.entities.Generation.filter({ id }, '-created_date', 1)
      .then(gens => {
        if (!gens || gens.length === 0) { setNotFound(true); setLoading(false); return; }
        const gen = gens[0];
        setTitle(gen.title || 'Website');
        const sections = (gen.sections || []).sort((a, b) => (a.order || 0) - (b.order || 0));
        const allHtml = sections.map(s => s.html).join('\n');
        const full = `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>${gen.title || 'Website'}</title><script src="https://cdn.tailwindcss.com"><\/script><link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet"><style>*{box-sizing:border-box;}body{font-family:'Inter',sans-serif;margin:0;padding:0;}</style></head><body>${allHtml}</body></html>`;
        setHtml(full);
        setLoading(false);
      })
      .catch(() => { setNotFound(true); setLoading(false); });
  }, [id]);

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  if (loading) return (
    <div style={{ background: '#030712', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'sans-serif' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ width: '40px', height: '40px', border: '3px solid rgba(245,158,11,0.2)', borderTopColor: '#f59e0b', borderRadius: '50%', margin: '0 auto 16px', animation: 'spin 0.8s linear infinite' }}></div>
        <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
        <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '14px' }}>Loading website...</div>
      </div>
    </div>
  );

  if (notFound) return (
    <div style={{ background: '#030712', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'sans-serif' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: '48px', marginBottom: '16px' }}>🔍</div>
        <div style={{ color: 'white', fontSize: '20px', fontWeight: '700', marginBottom: '8px' }}>Website not found</div>
        <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '14px' }}>This link may be invalid or the website was deleted.</div>
      </div>
    </div>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: '#030712' }}>
      {/* Top bar with URL + copy button */}
      <div style={{ background: 'rgba(3,7,18,0.97)', borderBottom: '1px solid rgba(245,158,11,0.2)', padding: '0 20px', height: '48px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0, zIndex: 1000 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{ width: '26px', height: '26px', borderRadius: '6px', background: 'linear-gradient(135deg,#f59e0b,#f97316)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '13px' }}>⚡</div>
          <span style={{ color: 'white', fontSize: '13px', fontWeight: '600', fontFamily: 'sans-serif', maxWidth: '300px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{title}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '6px', padding: '5px 14px', color: 'rgba(255,255,255,0.4)', fontSize: '12px', fontFamily: 'monospace', maxWidth: '380px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {window.location.href}
          </div>
          <button
            onClick={copyLink}
            style={{ padding: '6px 18px', borderRadius: '6px', background: copied ? '#22c55e' : 'linear-gradient(135deg,#f59e0b,#f97316)', color: copied ? 'white' : '#030712', fontSize: '12px', fontWeight: '700', border: 'none', cursor: 'pointer', transition: 'all 0.2s', fontFamily: 'sans-serif', whiteSpace: 'nowrap' }}
          >
            {copied ? '✓ Copied!' : '🔗 Copy Link'}
          </button>
        </div>
      </div>
      {/* Full website iframe */}
      <iframe
        srcDoc={html}
        style={{ flex: 1, border: 'none', width: '100%' }}
        title={title}
        sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
      />
    </div>
  );
}