import { useEffect, useState } from 'react';

export default function SplashScreen({ onComplete }) {
  const [phase, setPhase] = useState('in'); // in | hold | out

  useEffect(() => {
    const t1 = setTimeout(() => setPhase('hold'), 600);
    const t2 = setTimeout(() => setPhase('out'), 2400);
    const t3 = setTimeout(() => onComplete(), 3000);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onComplete]);

  return (
    <div
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-background overflow-hidden"
      style={{
        opacity: phase === 'out' ? 0 : 1,
        transition: phase === 'out' ? 'opacity 0.6s ease-in-out' : 'none',
      }}
    >
      {/* Animated background orbs */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute rounded-full"
          style={{
            width: 600, height: 600,
            background: 'radial-gradient(circle, hsl(43 96% 56% / 0.15) 0%, transparent 70%)',
            top: '50%', left: '50%',
            transform: 'translate(-50%, -50%)',
            animation: 'splash-pulse 2s ease-in-out infinite',
          }}
        />
        <div
          className="absolute rounded-full"
          style={{
            width: 300, height: 300,
            background: 'radial-gradient(circle, hsl(43 96% 56% / 0.08) 0%, transparent 70%)',
            top: '30%', left: '30%',
            animation: 'splash-float1 3s ease-in-out infinite',
          }}
        />
        <div
          className="absolute rounded-full"
          style={{
            width: 200, height: 200,
            background: 'radial-gradient(circle, hsl(43 96% 56% / 0.06) 0%, transparent 70%)',
            bottom: '25%', right: '25%',
            animation: 'splash-float2 4s ease-in-out infinite',
          }}
        />
      </div>

      {/* Grid overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-5"
        style={{
          backgroundImage: 'linear-gradient(hsl(43 96% 56%) 1px, transparent 1px), linear-gradient(90deg, hsl(43 96% 56%) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      {/* Logo */}
      <div
        className="relative z-10 flex flex-col items-center gap-6"
        style={{
          opacity: phase === 'in' ? 0 : 1,
          transform: phase === 'in' ? 'translateY(20px) scale(0.95)' : 'translateY(0) scale(1)',
          transition: 'all 0.7s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      >
        {/* Icon */}
        <div className="relative">
          <div
            className="absolute inset-0 rounded-2xl"
            style={{
              background: 'hsl(43 96% 56% / 0.3)',
              filter: 'blur(20px)',
              transform: 'scale(1.3)',
              animation: 'splash-glow 2s ease-in-out infinite alternate',
            }}
          />
          <div className="relative w-20 h-20 rounded-2xl bg-primary flex items-center justify-center shadow-2xl">
            <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
              <path d="M8 8h10v10H8zM22 8h10v10H22zM8 22h10v10H8zM22 22l10-10v10H22z" fill="hsl(0 0% 4%)" opacity="0.9"/>
              <circle cx="27" cy="27" r="3" fill="hsl(0 0% 4%)" opacity="0.7"/>
            </svg>
          </div>
        </div>

        {/* Name */}
        <div className="text-center">
          <div
            className="font-mono font-black text-5xl tracking-tight text-foreground"
            style={{ letterSpacing: '-0.02em' }}
          >
            AUTO<span className="text-primary">WEB</span>
          </div>
          <div className="font-mono text-xs text-muted-foreground tracking-[0.3em] uppercase mt-2">
            AI Website Generator
          </div>
        </div>

        {/* Loading bar */}
        <div className="w-48 h-px bg-border overflow-hidden rounded-full mt-2">
          <div
            className="h-full bg-primary rounded-full"
            style={{
              width: phase === 'hold' || phase === 'out' ? '100%' : '0%',
              transition: 'width 1.6s cubic-bezier(0.4, 0, 0.2, 1)',
            }}
          />
        </div>

        {/* Tagline */}
        <div
          className="font-mono text-xs text-muted-foreground tracking-widest"
          style={{
            opacity: phase === 'hold' || phase === 'out' ? 1 : 0,
            transition: 'opacity 0.5s ease 0.3s',
          }}
        >
          INTENT → INTERFACE
        </div>
      </div>

      {/* Corner decorations */}
      <div className="absolute top-8 left-8 w-8 h-8 border-l border-t border-primary/30" />
      <div className="absolute top-8 right-8 w-8 h-8 border-r border-t border-primary/30" />
      <div className="absolute bottom-8 left-8 w-8 h-8 border-l border-b border-primary/30" />
      <div className="absolute bottom-8 right-8 w-8 h-8 border-r border-b border-primary/30" />

      <style>{`
        @keyframes splash-pulse {
          0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
          50% { transform: translate(-50%, -50%) scale(1.1); opacity: 0.7; }
        }
        @keyframes splash-float1 {
          0%, 100% { transform: translate(0, 0); }
          50% { transform: translate(20px, -30px); }
        }
        @keyframes splash-float2 {
          0%, 100% { transform: translate(0, 0); }
          50% { transform: translate(-15px, 20px); }
        }
        @keyframes splash-glow {
          from { opacity: 0.5; transform: scale(1.2); }
          to { opacity: 1; transform: scale(1.5); }
        }
      `}</style>
    </div>
  );
}