const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState, useRef } from 'react';

import { Users } from 'lucide-react';

const COLORS = ['#f59e0b', '#3b82f6', '#10b981', '#f43f5e', '#8b5cf6', '#06b6d4', '#ec4899'];

function getColor(email) {
  let hash = 0;
  for (let i = 0; i < email.length; i++) hash = email.charCodeAt(i) + ((hash << 5) - hash);
  return COLORS[Math.abs(hash) % COLORS.length];
}

function getInitials(email, name) {
  if (name && name !== email) return name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
  return email.slice(0, 2).toUpperCase();
}

export default function CollabPresence({ generationId, currentUser, activeSection, onSectionFocus }) {
  const [sessions, setSessions] = useState([]);
  const sessionIdRef = useRef(null);

  // Upsert our session and keep it alive
  useEffect(() => {
    if (!generationId || !currentUser) return;

    let interval;

    const initSession = async () => {
      try {
        const existing = await db.entities.CollabSession.filter({
          generation_id: generationId,
          user_email: currentUser.email,
        });
        if (existing.length > 0) {
          sessionIdRef.current = existing[0].id;
          await db.entities.CollabSession.update(sessionIdRef.current, {
            last_seen: new Date().toISOString(),
            active_section: activeSection || '',
            color: getColor(currentUser.email),
            user_name: currentUser.full_name || currentUser.email,
          });
        } else {
          const s = await db.entities.CollabSession.create({
            generation_id: generationId,
            user_email: currentUser.email,
            user_name: currentUser.full_name || currentUser.email,
            color: getColor(currentUser.email),
            active_section: activeSection || '',
            last_seen: new Date().toISOString(),
          });
          sessionIdRef.current = s.id;
        }
      } catch (e) { /* silent */ }
    };

    initSession();
    interval = setInterval(async () => {
      if (sessionIdRef.current) {
        try {
          await db.entities.CollabSession.update(sessionIdRef.current, {
            last_seen: new Date().toISOString(),
            active_section: activeSection || '',
          });
        } catch (e) { /* silent */ }
      }
    }, 8000);

    return () => {
      clearInterval(interval);
      // Mark session as gone
      if (sessionIdRef.current) {
        db.entities.CollabSession.delete(sessionIdRef.current).catch(() => {});
      }
    };
  }, [generationId, currentUser]);

  // Update active_section when it changes
  useEffect(() => {
    if (sessionIdRef.current) {
      db.entities.CollabSession.update(sessionIdRef.current, {
        active_section: activeSection || '',
      }).catch(() => {});
    }
  }, [activeSection]);

  // Subscribe to all sessions for this generation
  useEffect(() => {
    if (!generationId) return;

    const loadSessions = async () => {
      try {
        const all = await db.entities.CollabSession.filter({ generation_id: generationId });
        const cutoff = Date.now() - 30000; // 30s timeout
        const active = all.filter(s =>
          s.user_email !== currentUser?.email &&
          new Date(s.last_seen).getTime() > cutoff
        );
        setSessions(active);
      } catch (e) { /* silent */ }
    };

    loadSessions();
    const unsub = db.entities.CollabSession.subscribe(() => loadSessions());
    return () => unsub();
  }, [generationId, currentUser]);

  if (sessions.length === 0) return null;

  return (
    <div className="flex items-center gap-1.5">
      <Users className="w-3.5 h-3.5 text-muted-foreground" />
      <div className="flex -space-x-1.5">
        {sessions.map((s) => (
          <div
            key={s.id}
            title={`${s.user_name || s.user_email}${s.active_section ? ` — editing ${s.active_section}` : ''}`}
            className="w-7 h-7 rounded-full border-2 border-background flex items-center justify-center text-xs font-bold text-white cursor-default shadow-sm"
            style={{ backgroundColor: s.color || '#f59e0b', zIndex: 1 }}
          >
            {getInitials(s.user_email, s.user_name)}
          </div>
        ))}
      </div>
      <span className="text-xs text-muted-foreground font-mono">
        {sessions.length} online
      </span>
    </div>
  );
}