import { useState } from 'react';
import { X, Sparkles, User, Mail, Lock, CheckCircle } from 'lucide-react';

export default function CreateAccountModal({ isOpen, onClose, planName }) {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ name: '', email: '', password: '' });

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    setStep(2);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
      <div className="bg-card border border-border rounded-2xl w-full max-w-md p-8 relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-muted-foreground hover:text-foreground">
          <X className="w-5 h-5" />
        </button>

        {step === 1 ? (
          <>
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-mono font-bold text-lg">AUTOWEB</span>
            </div>
            <h2 className="text-2xl font-bold mb-1">Create free account</h2>
            {planName && <p className="text-muted-foreground text-sm mb-6">You selected the <span className="text-primary font-semibold">{planName}</span> plan</p>}
            {!planName && <p className="text-muted-foreground text-sm mb-6">Start building websites for free — no credit card required.</p>}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-mono text-muted-foreground block mb-1.5">FULL NAME</label>
                <div className="relative">
                  <User className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
                  <input
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full bg-secondary border border-border rounded-lg pl-9 pr-3 py-2.5 text-sm focus:outline-none focus:border-primary/60 text-foreground placeholder:text-muted-foreground"
                    placeholder="John Doe"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-mono text-muted-foreground block mb-1.5">EMAIL</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
                  <input
                    required
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="w-full bg-secondary border border-border rounded-lg pl-9 pr-3 py-2.5 text-sm focus:outline-none focus:border-primary/60 text-foreground placeholder:text-muted-foreground"
                    placeholder="you@example.com"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-mono text-muted-foreground block mb-1.5">PASSWORD</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
                  <input
                    required
                    type="password"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    className="w-full bg-secondary border border-border rounded-lg pl-9 pr-3 py-2.5 text-sm focus:outline-none focus:border-primary/60 text-foreground placeholder:text-muted-foreground"
                    placeholder="••••••••"
                  />
                </div>
              </div>
              <button type="submit" className="w-full py-3 rounded-lg bg-primary text-primary-foreground font-mono font-semibold text-sm hover:bg-primary/90 transition-colors mt-2">
                CREATE FREE ACCOUNT →
              </button>
            </form>
            <p className="text-xs text-muted-foreground text-center mt-4">
              By signing up you agree to our Terms of Service.
            </p>
          </>
        ) : (
          <div className="flex flex-col items-center py-6 text-center">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8 text-primary" />
            </div>
            <h2 className="text-2xl font-bold mb-2">You're in! 🎉</h2>
            <p className="text-muted-foreground mb-6">Account created for <span className="text-foreground font-medium">{form.email}</span></p>
            <button onClick={onClose} className="px-8 py-3 rounded-lg bg-primary text-primary-foreground font-mono font-semibold text-sm hover:bg-primary/90 transition-colors">
              CONTINUE BUILDING
            </button>
          </div>
        )}
      </div>
    </div>
  );
}