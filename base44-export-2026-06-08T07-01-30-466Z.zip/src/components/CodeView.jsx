import { ScrollArea } from '@/components/ui/scroll-area';
import { Copy } from 'lucide-react';
import { toast } from 'sonner';

export default function CodeView({ sections }) {
  const fullHTML = sections
    .sort((a, b) => (a.order || 0) - (b.order || 0))
    .map((s) => `<!-- ${s.name} -->\n${s.html}`)
    .join('\n\n');

  const copyAll = () => {
    navigator.clipboard.writeText(fullHTML);
    toast.success('Code copied to clipboard');
  };

  return (
    <div className="flex-1 bg-secondary/20 relative">
      <button
        onClick={copyAll}
        className="absolute top-3 right-3 z-10 flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-secondary border border-border text-xs font-mono text-muted-foreground hover:text-foreground transition-colors"
      >
        <Copy className="w-3.5 h-3.5" />
        COPY ALL
      </button>
      <ScrollArea className="h-full">
        <pre className="p-6 text-xs font-mono text-muted-foreground leading-relaxed whitespace-pre-wrap break-all">
          {fullHTML}
        </pre>
      </ScrollArea>
    </div>
  );
}