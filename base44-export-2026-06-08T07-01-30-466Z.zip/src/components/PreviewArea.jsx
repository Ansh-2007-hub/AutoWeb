import { useRef, useMemo, useEffect } from 'react';

const VIEWPORT_WIDTHS = {
  desktop: '100%',
  tablet: '768px',
  mobile: '375px',
};

export default function PreviewArea({ sections, onCtaClick, viewport = 'desktop' }) {
  const iframeRef = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === 'CTA_CLICK') {
        onCtaClick?.(e.data.text, e.data.plan);
      }
    };
    window.addEventListener('message', handler);
    return () => window.removeEventListener('message', handler);
  }, [onCtaClick]);

  const html = useMemo(() => {
    const allHtml = sections
      .sort((a, b) => (a.order || 0) - (b.order || 0))
      .map((s) => s.html)
      .join('\n');

    const ctaScript = `
<script>
(function(){
  const CTA_PATTERNS = /start free|create account|get started|sign up|try free|begin|join|subscribe|buy now|get plan|download/i;
  document.addEventListener('click', function(e) {
    const btn = e.target.closest('a,button,[role=button]');
    if (!btn) return;
    const text = btn.innerText || btn.textContent || '';
    if (CTA_PATTERNS.test(text)) {
      const plan = btn.closest('[data-plan]')?.dataset?.plan ||
                   btn.closest('.pricing-plan,.plan,.card')?.querySelector('h3,h2')?.innerText || '';
      window.parent.postMessage({ type: 'CTA_CLICK', text: text.trim(), plan }, '*');
    }
    e.preventDefault();
  });
})();
<\/script>`;

    return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"><\/script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Space+Grotesk:wght@400;500;600;700&family=Sora:wght@300;400;600;800&display=swap" rel="stylesheet">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Inter', sans-serif; }
  html { scroll-behavior: smooth; }
  video { display: none !important; }
</style>
${ctaScript}
</head>
<body>
${allHtml}
</body>
</html>`;
  }, [sections]);

  const iframeWidth = VIEWPORT_WIDTHS[viewport] || '100%';
  const isConstrained = viewport !== 'desktop';

  return (
    <div className="flex-1 bg-secondary/20 flex flex-col items-center overflow-auto">
      <div
        className="h-full transition-all duration-300"
        style={{ width: iframeWidth, minHeight: '100%' }}
      >
        {isConstrained && (
          <div className="text-center py-1 text-xs font-mono text-muted-foreground bg-secondary/40 border-b border-border">
            {viewport.toUpperCase()} — {iframeWidth}
          </div>
        )}
        <iframe
          ref={iframeRef}
          srcDoc={html}
          style={{ width: '100%', height: isConstrained ? 'calc(100% - 24px)' : '100%' }}
          className="border-0"
          title="Preview"
          sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
        />
      </div>
    </div>
  );
}