const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { Plus, Clock, Sparkles, Layers, LogOut, ChevronUp, ExternalLink } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';

import { ScrollArea } from '@/components/ui/scroll-area';
import moment from 'moment';

export default function Sidebar({ activeId, onSelect, onNew }) {
  const { user } = useAuth();
  const { data: generations = [] } = useQuery({
    queryKey: ['generations', user?.email],
    queryFn: () => user ? db.entities.Generation.filter({ created_by: user.email }, '-created_date', 50) : [],
    enabled: !!user,
  });

  return (
    <div className="w-64 h-screen bg-sidebar border-r border-sidebar-border flex flex-col shrink-0">
      {/* Header */}
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-7 h-7 rounded-md bg-primary flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-mono font-bold text-foreground tracking-tight">AUTOWEB</span>
        </div>
        <button
          onClick={onNew}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-md border border-border text-sm font-mono text-muted-foreground hover:text-foreground hover:border-primary/50 transition-colors"
        >
          <Plus className="w-4 h-4" />
          NEW GENERATION
        </button>
      </div>

      {/* History label */}
      <div className="px-4 pt-4 pb-2">
        <div className="flex items-center gap-1.5 text-xs font-mono text-muted-foreground tracking-wider">
          <Clock className="w-3 h-3" />
          HISTORY
        </div>
      </div>

      {/* Generations list */}
      <ScrollArea className="flex-1 px-2">
        <div className="space-y-0.5 pb-4">
          {generations.map((gen) => {
            const isCharioteer = gen.title && gen.title.toLowerCase().includes('charioteer');
            return (
              <div key={gen.id} className="relative group">
                <button
                  onClick={() => onSelect(gen)}
                  className={`w-full text-left px-3 py-2.5 rounded-md transition-colors ${
                    activeId === gen.id
                      ? 'bg-sidebar-accent text-foreground'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                  }`}
                >
                  <div className="text-sm truncate font-medium flex items-center gap-1.5">
                    {isCharioteer && <span className="text-primary">⚡</span>}
                    {gen.title}
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1.5">
                    {moment(gen.created_date).format('M/D/YYYY')}
                    <span>·</span>
                    <Layers className="w-3 h-3 inline" />
                    {gen.section_count || gen.sections?.length || 0} sections
                    {isCharioteer && <span className="text-primary font-semibold">· LIVE</span>}
                  </div>
                </button>
                {isCharioteer && (
                  <a
                    href="/charioteer"
                    target="_blank"
                    rel="noreferrer"
                    title="Open live multi-page site"
                    className="absolute right-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-sidebar-accent text-primary transition-all"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            );
          })}
        </div>
      </ScrollArea>

      {/* Profile footer */}
      <ProfileFooter user={user} />
    </div>
  );
}

function ProfileFooter({ user }) {
  const [open, setOpen] = useState(false);
  const avatarUrl = user
    ? `https://api.dicebear.com/9.x/avataaars/svg?seed=${encodeURIComponent(user.email)}&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf`
    : null;

  return (
    <div className="relative border-t border-sidebar-border p-3 shrink-0">
      {open && (
        <div className="absolute bottom-full left-2 right-2 mb-1 bg-card border border-border rounded-lg shadow-xl overflow-hidden z-50">
          <div className="px-4 py-3 border-b border-border">
            <div className="text-sm font-medium text-foreground truncate">{user?.full_name || 'User'}</div>
            <div className="text-xs text-muted-foreground truncate">{user?.email}</div>
          </div>
          <button
            onClick={() => db.auth.logout()}
            className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-destructive hover:bg-destructive/10 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Sign out
          </button>
        </div>
      )}

      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-3 px-2 py-1.5 rounded-md hover:bg-sidebar-accent/50 transition-colors"
      >
        {avatarUrl ? (
          <img src={avatarUrl} alt="avatar" className="w-8 h-8 rounded-full bg-secondary shrink-0" />
        ) : (
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs font-bold shrink-0">
            {user?.email?.[0]?.toUpperCase() || 'U'}
          </div>
        )}
        <div className="flex-1 min-w-0 text-left">
          <div className="text-sm font-medium text-foreground truncate">{user?.full_name || user?.email || 'Profile'}</div>
          <div className="text-xs text-muted-foreground">Free plan</div>
        </div>
        <ChevronUp className={`w-3.5 h-3.5 text-muted-foreground transition-transform ${open ? '' : 'rotate-180'}`} />
      </button>
    </div>
  );
}