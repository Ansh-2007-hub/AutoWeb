const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';
import { DollarSign, Plus, Trash2, Save, Sparkles } from 'lucide-react';

import { toast } from 'sonner';

const DEFAULT_PLANS = [
  { id: '1', name: 'Free', price: '0', period: 'month', features: ['5 projects', '1 user', 'Basic support'], cta: 'Get Started Free', highlight: false },
  { id: '2', name: 'Pro', price: '29', period: 'month', features: ['Unlimited projects', '5 users', 'Priority support', 'Custom domain'], cta: 'Start Pro Trial', highlight: true },
  { id: '3', name: 'Enterprise', price: '99', period: 'month', features: ['Everything in Pro', 'Unlimited users', 'SLA support', 'SSO'], cta: 'Contact Sales', highlight: false },
];

export default function PricingEditor({ section, onUpdate }) {
  const [plans, setPlans] = useState(() => {
    try {
      const parsed = JSON.parse(section._pricingData || 'null');
      return parsed || DEFAULT_PLANS;
    } catch {
      return DEFAULT_PLANS;
    }
  });
  const [isGenerating, setIsGenerating] = useState(false);

  const updatePlan = (id, field, val) => setPlans(plans.map(p => p.id === id ? { ...p, [field]: val } : p));
  const updateFeature = (planId, idx, val) => setPlans(plans.map(p => p.id === planId ? { ...p, features: p.features.map((f, i) => i === idx ? val : f) } : p));
  const addFeature = (planId) => setPlans(plans.map(p => p.id === planId ? { ...p, features: [...p.features, 'New feature'] } : p));
  const removeFeature = (planId, idx) => setPlans(plans.map(p => p.id === planId ? { ...p, features: p.features.filter((_, i) => i !== idx) } : p));
  const addPlan = () => setPlans([...plans, { id: Date.now().toString(), name: 'New Plan', price: '49', period: 'month', features: ['Feature 1'], cta: 'Get Started', highlight: false }]);
  const removePlan = (id) => setPlans(plans.filter(p => p.id !== id));

  const applyToPreview = async () => {
    setIsGenerating(true);
    const result = await db.integrations.Core.InvokeLLM({
      prompt: `Generate a beautiful pricing section HTML using Tailwind CSS for these plans:
${JSON.stringify(plans, null, 2)}
Return JSON with "html" key. Make it modern, clean, production-quality with a pricing grid. Include a title "Simple, Transparent Pricing". Use a dark or light style that looks professional. The highlight plan should stand out visually.`,
      response_json_schema: { type: 'object', properties: { html: { type: 'string' } } },
      model: 'gemini_3_flash',
    });
    onUpdate(section.id, result.html, JSON.stringify(plans));
    setIsGenerating(false);
    toast.success('Pricing section updated!');
  };

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <span className="text-xs font-mono text-muted-foreground flex items-center gap-1"><DollarSign className="w-3 h-3" /> PRICING EDITOR</span>
        <button onClick={addPlan} className="flex items-center gap-1 text-xs text-primary hover:underline"><Plus className="w-3 h-3" /> Add Plan</button>
      </div>

      <div className="space-y-3">
        {plans.map((plan) => (
          <div key={plan.id} className="border border-border rounded-lg p-3 space-y-2 bg-secondary/30">
            <div className="flex items-center gap-2">
              <input
                value={plan.name}
                onChange={(e) => updatePlan(plan.id, 'name', e.target.value)}
                className="flex-1 bg-secondary border border-border rounded px-2 py-1 text-sm focus:outline-none focus:border-primary/50 text-foreground"
                placeholder="Plan name"
              />
              <div className="flex items-center gap-1 bg-secondary border border-border rounded px-2 py-1">
                <span className="text-xs text-muted-foreground">$</span>
                <input
                  value={plan.price}
                  onChange={(e) => updatePlan(plan.id, 'price', e.target.value)}
                  className="w-12 bg-transparent text-sm focus:outline-none text-foreground"
                  placeholder="0"
                />
                <span className="text-xs text-muted-foreground">/mo</span>
              </div>
              <button onClick={() => removePlan(plan.id)} className="text-muted-foreground hover:text-destructive">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
            <div>
              <input
                value={plan.cta}
                onChange={(e) => updatePlan(plan.id, 'cta', e.target.value)}
                className="w-full bg-secondary border border-border rounded px-2 py-1 text-xs focus:outline-none focus:border-primary/50 text-muted-foreground placeholder:text-muted-foreground"
                placeholder="CTA button text"
              />
            </div>
            <div className="space-y-1">
              {plan.features.map((f, i) => (
                <div key={i} className="flex items-center gap-1">
                  <input
                    value={f}
                    onChange={(e) => updateFeature(plan.id, i, e.target.value)}
                    className="flex-1 bg-secondary border border-border rounded px-2 py-1 text-xs focus:outline-none focus:border-primary/50 text-foreground"
                  />
                  <button onClick={() => removeFeature(plan.id, i)} className="text-muted-foreground hover:text-destructive">
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              ))}
              <button onClick={() => addFeature(plan.id)} className="text-xs text-muted-foreground hover:text-primary flex items-center gap-1">
                <Plus className="w-3 h-3" /> feature
              </button>
            </div>
            <label className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer">
              <input type="checkbox" checked={plan.highlight} onChange={(e) => updatePlan(plan.id, 'highlight', e.target.checked)} className="accent-primary" />
              Highlight this plan
            </label>
          </div>
        ))}
      </div>

      <button
        onClick={applyToPreview}
        disabled={isGenerating}
        className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-primary text-primary-foreground text-xs font-mono font-semibold hover:bg-primary/90 disabled:opacity-50 transition-colors"
      >
        {isGenerating ? <div className="w-3.5 h-3.5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
        {isGenerating ? 'REGENERATING...' : 'APPLY TO PREVIEW'}
      </button>
    </div>
  );
}