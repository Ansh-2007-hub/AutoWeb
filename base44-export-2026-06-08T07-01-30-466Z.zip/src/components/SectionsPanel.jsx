import { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { ChevronRight, ChevronDown, RefreshCw, Trash2, Sparkles, Layers, DollarSign, Layout, Navigation, Star, MessageSquare, Users, HelpCircle, Mail, Image, GripVertical } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import PricingEditor from './PricingEditor';

const SECTION_ICONS = {
  nav: Navigation, navigation: Navigation, header: Navigation,
  hero: Star, banner: Star, intro: Star,
  features: Layout, feature: Layout, capabilities: Layout,
  pricing: DollarSign, plans: DollarSign,
  testimonials: MessageSquare, reviews: MessageSquare, social: MessageSquare,
  team: Users, about: Users,
  faq: HelpCircle,
  footer: Mail, contact: Mail,
  gallery: Image, portfolio: Image,
};

const EDIT_PRESETS = [
  { label: 'Change headline text', value: 'Rewrite the main headline to be more compelling and bold' },
  { label: 'Make it darker', value: 'Change to a dark background with light text, keep the same layout' },
  { label: 'Make it lighter', value: 'Change to a clean white/light background, modern bright design' },
  { label: 'Add more visual elements', value: 'Add more decorative elements, icons, gradient accents, and visual interest' },
  { label: 'Bigger CTA buttons', value: 'Make the call-to-action buttons larger, more prominent and colorful' },
  { label: 'Improve typography', value: 'Use better font sizes, weights and spacing for better readability' },
  { label: 'Add background gradient', value: 'Add a beautiful gradient background to make the section more visually striking' },
  { label: 'Make more minimal', value: 'Simplify the design, remove clutter, more white space and minimal aesthetic' },
];

function getSectionIcon(section) {
  const id = (section.id || '').toLowerCase();
  const name = (section.name || '').toLowerCase();
  for (const [key, Icon] of Object.entries(SECTION_ICONS)) {
    if (id.includes(key) || name.includes(key)) return Icon;
  }
  return Layout;
}

function getSectionLabel(section) {
  const name = (section.name || '').toLowerCase();
  if (name.includes('nav') || name.includes('header')) return 'Navigation & Logo';
  if (name.includes('hero') || name.includes('banner')) return 'Hero — Headline & CTA';
  if (name.includes('feat') || name.includes('capab')) return 'Features & Benefits';
  if (name.includes('pric') || name.includes('plan')) return 'Pricing Plans';
  if (name.includes('test') || name.includes('review')) return 'Testimonials & Reviews';
  if (name.includes('team') || name.includes('about')) return 'Team & About';
  if (name.includes('faq')) return 'FAQ';
  if (name.includes('footer') || name.includes('contact')) return 'Footer & Contact';
  if (name.includes('gallery') || name.includes('portf')) return 'Gallery / Portfolio';
  return section.name || 'Section';
}

function SectionItem({ section, onRegenerate, onDelete, onPricingUpdate, isRegenerating, dragHandleProps }) {
  const [expanded, setExpanded] = useState(false);
  const [editPrompt, setEditPrompt] = useState('');
  const isPricing = (section.name || '').toLowerCase().includes('pric') || (section.id || '').toLowerCase().includes('pric');
  const Icon = getSectionIcon(section);
  const label = getSectionLabel(section);

  return (
    <div className="border-b border-border last:border-0">
      <div className="w-full flex items-center gap-2 px-3 py-3 hover:bg-secondary/50 transition-colors">
        {/* Drag handle */}
        <div {...dragHandleProps} className="cursor-grab active:cursor-grabbing text-muted-foreground hover:text-foreground p-0.5 shrink-0">
          <GripVertical className="w-3.5 h-3.5" />
        </div>

        <div
          onClick={() => setExpanded(!expanded)}
          className="flex items-center gap-2 flex-1 min-w-0 cursor-pointer"
        >
          {expanded ? <ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0" /> : <ChevronRight className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
          <Icon className="w-3.5 h-3.5 text-primary shrink-0" />
          <div className="flex-1 min-w-0 text-left">
            <div className="text-sm font-medium truncate">{label}</div>
            <div className="text-xs text-muted-foreground truncate">{section.id}</div>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <div
            onClick={() => onRegenerate(section.id, '')}
            className="p-1 rounded hover:bg-secondary text-muted-foreground hover:text-foreground cursor-pointer"
            title="Regenerate"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRegenerating ? 'animate-spin' : ''}`} />
          </div>
          <div
            onClick={() => onDelete(section.id)}
            className="p-1 rounded hover:bg-destructive/20 text-muted-foreground hover:text-destructive cursor-pointer"
            title="Delete section"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>

      {expanded && (
        <div className="px-4 pb-4 space-y-3">
          {isPricing ? (
            <PricingEditor section={section} onUpdate={onPricingUpdate} />
          ) : (
            <>
              <div className="text-xs font-mono text-muted-foreground tracking-wider">QUICK EDITS</div>
              <div className="flex flex-wrap gap-1.5">
                {EDIT_PRESETS.map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => setEditPrompt(preset.value)}
                    className="text-xs px-2 py-1 rounded border border-border text-muted-foreground hover:text-foreground hover:border-primary/40 transition-colors"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
              <div className="text-xs font-mono text-muted-foreground tracking-wider mt-2">DESCRIBE CHANGES</div>
              <textarea
                value={editPrompt}
                onChange={(e) => setEditPrompt(e.target.value)}
                placeholder="e.g. Change headline to 'Build Faster', use purple gradient..."
                rows={2}
                className="w-full bg-secondary/50 border border-border rounded-md px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 resize-none"
              />
              <button
                onClick={() => { onRegenerate(section.id, editPrompt); setEditPrompt(''); }}
                disabled={isRegenerating}
                className="w-full flex items-center justify-center gap-2 py-2 rounded-md bg-primary text-primary-foreground text-xs font-mono font-semibold hover:bg-primary/90 disabled:opacity-40 transition-colors"
              >
                {isRegenerating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                {isRegenerating ? 'REGENERATING...' : 'REGENERATE WITH AI'}
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}

export default function SectionsPanel({ sections, onRegenerate, onDelete, onPricingUpdate, regeneratingId, onReorder }) {
  const sorted = [...sections].sort((a, b) => (a.order || 0) - (b.order || 0));

  const handleDragEnd = ({ source, destination }) => {
    if (!destination || destination.index === source.index) return;
    const reordered = [...sorted];
    const [moved] = reordered.splice(source.index, 1);
    reordered.splice(destination.index, 0, moved);
    // Reassign order values
    const updated = reordered.map((s, i) => ({ ...s, order: i }));
    onReorder(updated);
  };

  return (
    <div className="w-72 h-full border-l border-border bg-card flex flex-col shrink-0">
      <div className="px-4 py-3 border-b border-border flex items-center justify-between">
        <span className="text-sm font-mono font-semibold tracking-wider">SECTIONS</span>
        <span className="text-xs text-muted-foreground flex items-center gap-1">
          <Layers className="w-3 h-3" />
          {sections.length}
        </span>
      </div>
      <ScrollArea className="flex-1">
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="sections">
            {(provided) => (
              <div ref={provided.innerRef} {...provided.droppableProps}>
                {sorted.map((section, idx) => (
                  <Draggable key={section.id} draggableId={section.id} index={idx}>
                    {(p) => (
                      <div
                        ref={p.innerRef}
                        {...p.draggableProps}
                        className="select-none"
                      >
                        <SectionItem
                          section={section}
                          onRegenerate={onRegenerate}
                          onDelete={onDelete}
                          onPricingUpdate={onPricingUpdate}
                          isRegenerating={regeneratingId === section.id}
                          dragHandleProps={p.dragHandleProps}
                        />
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </ScrollArea>
    </div>
  );
}